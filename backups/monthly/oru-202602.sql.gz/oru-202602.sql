--
-- PostgreSQL database dump
--

\restrict erNzoVyUqWtYM7Yb8wpVOfUsauAd1iaknCei9BRnyVtZ6F9d1fnjjiwTZVeXHC2

-- Dumped from database version 15.16
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO postgres;

--
-- Name: agency_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.agency_status AS ENUM (
    'active',
    'suspended',
    'cancelled',
    'pending'
);


ALTER TYPE public.agency_status OWNER TO postgres;

--
-- Name: agency_tier; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.agency_tier AS ENUM (
    'trial',
    'starter',
    'basic',
    'professional',
    'enterprise',
    'custom'
);


ALTER TYPE public.agency_tier OWNER TO postgres;

--
-- Name: alert_severity; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.alert_severity AS ENUM (
    'info',
    'warning',
    'error',
    'critical'
);


ALTER TYPE public.alert_severity OWNER TO postgres;

--
-- Name: audit_action; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.audit_action AS ENUM (
    'create',
    'update',
    'delete',
    'login',
    'logout',
    'access',
    'export',
    'import'
);


ALTER TYPE public.audit_action OWNER TO postgres;

--
-- Name: email_provider_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.email_provider_type AS ENUM (
    'smtp',
    'sendgrid',
    'mailgun',
    'aws_ses',
    'resend',
    'postmark'
);


ALTER TYPE public.email_provider_type OWNER TO postgres;

--
-- Name: health_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.health_status AS ENUM (
    'healthy',
    'degraded',
    'down',
    'maintenance'
);


ALTER TYPE public.health_status OWNER TO postgres;

--
-- Name: log_level_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.log_level_type AS ENUM (
    'debug',
    'info',
    'warn',
    'error',
    'fatal'
);


ALTER TYPE public.log_level_type OWNER TO postgres;

--
-- Name: page_assignment_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.page_assignment_status AS ENUM (
    'active',
    'pending_approval',
    'suspended',
    'trial',
    'expired'
);


ALTER TYPE public.page_assignment_status OWNER TO postgres;

--
-- Name: page_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.page_category AS ENUM (
    'dashboard',
    'management',
    'finance',
    'hr',
    'projects',
    'reports',
    'personal',
    'settings',
    'system',
    'inventory',
    'procurement',
    'assets',
    'workflows',
    'automation',
    'compliance',
    'analytics'
);


ALTER TYPE public.page_category OWNER TO postgres;

--
-- Name: page_request_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.page_request_status AS ENUM (
    'pending',
    'approved',
    'rejected',
    'cancelled'
);


ALTER TYPE public.page_request_status OWNER TO postgres;

--
-- Name: provisioning_job_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.provisioning_job_status AS ENUM (
    'pending',
    'validating',
    'creating_database',
    'seeding_data',
    'assigning_permissions',
    'completed',
    'failed',
    'cancelled',
    'timeout'
);


ALTER TYPE public.provisioning_job_status OWNER TO postgres;

--
-- Name: storage_provider_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.storage_provider_type AS ENUM (
    'local',
    'aws_s3',
    'azure_blob',
    'gcp_storage',
    'digitalocean_spaces'
);


ALTER TYPE public.storage_provider_type OWNER TO postgres;

--
-- Name: twitter_card_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.twitter_card_type AS ENUM (
    'summary',
    'summary_large_image',
    'app',
    'player'
);


ALTER TYPE public.twitter_card_type OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'super_admin',
    'agency_admin',
    'manager',
    'employee',
    'auditor',
    'viewer',
    'custom'
);


ALTER TYPE public.user_role OWNER TO postgres;

--
-- Name: user_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_status AS ENUM (
    'active',
    'inactive',
    'suspended',
    'locked'
);


ALTER TYPE public.user_status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: postgres
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: postgres
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: postgres
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: agencies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    domain text NOT NULL,
    database_name text NOT NULL,
    owner_user_id uuid,
    subscription_plan public.agency_tier DEFAULT 'trial'::public.agency_tier NOT NULL,
    status public.agency_status DEFAULT 'pending'::public.agency_status NOT NULL,
    max_users integer DEFAULT 50 NOT NULL,
    max_storage_gb integer DEFAULT 10 NOT NULL,
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    contact_email text,
    contact_phone text,
    billing_email text,
    address jsonb,
    tax_id text,
    subscription_starts_at timestamp with time zone,
    subscription_ends_at timestamp with time zone,
    trial_ends_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agencies OWNER TO postgres;

--
-- Name: agency_page_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agency_page_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agency_id uuid NOT NULL,
    page_id uuid NOT NULL,
    status public.page_assignment_status DEFAULT 'active'::public.page_assignment_status NOT NULL,
    cost_override numeric(12,2),
    billing_cycle_override text,
    discount_percent numeric(5,2) DEFAULT '0'::numeric,
    is_trial boolean DEFAULT false NOT NULL,
    trial_started_at timestamp with time zone,
    trial_ends_at timestamp with time zone,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    assigned_by uuid,
    activated_at timestamp with time zone,
    suspended_at timestamp with time zone,
    suspended_by uuid,
    suspension_reason text,
    expires_at timestamp with time zone,
    auto_renew boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    last_accessed_at timestamp with time zone,
    custom_quota jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agency_page_assignments OWNER TO postgres;

--
-- Name: agency_page_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agency_page_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agency_id uuid NOT NULL,
    page_id uuid NOT NULL,
    requested_by uuid NOT NULL,
    status public.page_request_status DEFAULT 'pending'::public.page_request_status NOT NULL,
    priority text DEFAULT 'normal'::text,
    reason text NOT NULL,
    business_justification text,
    expected_usage text,
    expected_users integer,
    budget_allocated numeric(12,2),
    desired_start_date date,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_notes text,
    approved_cost numeric(12,2),
    rejection_reason text,
    auto_approved boolean DEFAULT false NOT NULL,
    attachments jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agency_page_requests OWNER TO postgres;

--
-- Name: agency_provisioning_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agency_provisioning_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    idempotency_key text,
    status public.provisioning_job_status DEFAULT 'pending'::public.provisioning_job_status NOT NULL,
    domain text NOT NULL,
    database_name text NOT NULL,
    agency_name text NOT NULL,
    owner_email text NOT NULL,
    subscription_plan text,
    requested_by uuid,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    validation_errors jsonb,
    progress_percentage integer DEFAULT 0 NOT NULL,
    current_step text,
    steps_completed text[] DEFAULT '{}'::text[],
    steps_total integer,
    result jsonb,
    agency_id uuid,
    error_message text,
    error_code text,
    error_details jsonb,
    stack_trace text,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    next_retry_at timestamp with time zone,
    priority integer DEFAULT 5 NOT NULL,
    timeout_seconds integer DEFAULT 300 NOT NULL,
    worker_id text,
    worker_hostname text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    cancelled_by uuid,
    cancellation_reason text,
    estimated_completion_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agency_provisioning_jobs OWNER TO postgres;

--
-- Name: agency_provisioning_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agency_provisioning_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    level text NOT NULL,
    message text NOT NULL,
    step text,
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agency_provisioning_logs OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agency_id uuid,
    user_id uuid,
    session_id uuid,
    table_name text NOT NULL,
    record_id uuid,
    action public.audit_action NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    ip_address inet,
    user_agent text,
    request_id text,
    endpoint text,
    method text,
    status_code integer,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: currencies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.currencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(3) NOT NULL,
    name character varying(100) NOT NULL,
    symbol character varying(10),
    exchange_rate numeric(10,4) DEFAULT '1'::numeric,
    is_base boolean DEFAULT false,
    is_active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.currencies OWNER TO postgres;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_verification_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    email text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_verification_tokens OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    agency_id uuid,
    title text NOT NULL,
    message text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    link text,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: page_catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page_catalog (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    path text NOT NULL,
    title text NOT NULL,
    description text,
    icon text,
    category public.page_category NOT NULL,
    parent_page_id uuid,
    display_order integer DEFAULT 0 NOT NULL,
    base_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    billing_cycle text DEFAULT 'monthly'::text,
    min_subscription_tier text,
    required_features text[] DEFAULT '{}'::text[],
    dependent_pages uuid[],
    is_active boolean DEFAULT true NOT NULL,
    is_beta boolean DEFAULT false NOT NULL,
    requires_approval boolean DEFAULT false NOT NULL,
    requires_onboarding boolean DEFAULT false NOT NULL,
    has_trial boolean DEFAULT false NOT NULL,
    trial_duration_days integer,
    permissions_required text[] DEFAULT '{}'::text[],
    api_quota_default integer,
    storage_quota_mb integer,
    max_concurrent_users integer,
    seo_title text,
    seo_description text,
    seo_keywords text[],
    documentation_url text,
    video_tutorial_url text,
    support_email text,
    release_date date,
    deprecation_date date,
    replacement_page_id uuid,
    tags text[] DEFAULT '{}'::text[],
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    analytics_enabled boolean DEFAULT true NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_catalog OWNER TO postgres;

--
-- Name: page_pricing_tiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page_pricing_tiers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_id uuid NOT NULL,
    tier_name text NOT NULL,
    tier_level integer NOT NULL,
    cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    billing_cycle text DEFAULT 'monthly'::text NOT NULL,
    quota_overrides jsonb DEFAULT '{}'::jsonb NOT NULL,
    feature_flags jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    valid_from date,
    valid_until date,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_pricing_tiers OWNER TO postgres;

--
-- Name: page_recommendation_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page_recommendation_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_id uuid NOT NULL,
    industry text[],
    company_size text[],
    primary_focus text[],
    business_goals text[],
    priority integer DEFAULT 5 NOT NULL,
    weight numeric(5,2) DEFAULT 1.0 NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    min_employees integer,
    max_employees integer,
    min_revenue numeric(15,2),
    max_revenue numeric(15,2),
    geographic_regions text[],
    exclude_industries text[],
    custom_criteria jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_recommendation_rules OWNER TO postgres;

--
-- Name: page_usage_analytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.page_usage_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agency_id uuid NOT NULL,
    page_id uuid NOT NULL,
    user_id uuid,
    date date NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    unique_users integer DEFAULT 0 NOT NULL,
    total_duration_seconds integer DEFAULT 0 NOT NULL,
    avg_session_duration_seconds integer,
    action_count integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    performance_score numeric(5,2),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.page_usage_analytics OWNER TO postgres;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    ip_address inet,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    agency_id uuid,
    full_name text,
    display_name text,
    phone text,
    phone_extension text,
    department text,
    "position" text,
    employee_code text,
    hire_date date,
    avatar_url text,
    personal_email text,
    personal_email_verified boolean DEFAULT false NOT NULL,
    personal_email_verified_at timestamp with time zone,
    timezone text DEFAULT 'UTC'::text,
    language text DEFAULT 'en'::text,
    date_format text DEFAULT 'YYYY-MM-DD'::text,
    time_format text DEFAULT '24h'::text,
    notification_preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    theme_preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    bio text,
    social_links jsonb,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.profiles OWNER TO postgres;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    base_price_monthly numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    base_price_yearly numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    max_users integer DEFAULT 5 NOT NULL,
    max_storage_gb integer DEFAULT 1 NOT NULL,
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_plans OWNER TO postgres;

--
-- Name: system_alert_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_alert_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rule_name text NOT NULL,
    metric_name text NOT NULL,
    condition text NOT NULL,
    threshold_value numeric(15,2) NOT NULL,
    comparison_operator text NOT NULL,
    severity public.alert_severity NOT NULL,
    duration_seconds integer DEFAULT 60 NOT NULL,
    cooldown_seconds integer DEFAULT 300 NOT NULL,
    notification_channels text[] DEFAULT '{}'::text[] NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    description text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_alert_rules OWNER TO postgres;

--
-- Name: system_alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alert_rule_id uuid,
    severity public.alert_severity NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    metric_name text,
    current_value numeric(15,2),
    threshold_value numeric(15,2),
    status text DEFAULT 'active'::text NOT NULL,
    triggered_at timestamp with time zone DEFAULT now() NOT NULL,
    acknowledged_at timestamp with time zone,
    acknowledged_by uuid,
    resolved_at timestamp with time zone,
    resolved_by uuid,
    resolution_notes text,
    notification_sent boolean DEFAULT false NOT NULL,
    notification_sent_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_alerts OWNER TO postgres;

--
-- Name: system_features; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_features (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    feature_key text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_features OWNER TO postgres;

--
-- Name: system_health_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_health_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    overall_status public.health_status DEFAULT 'healthy'::public.health_status NOT NULL,
    db_status public.health_status,
    db_response_time_ms integer,
    db_size_bytes bigint,
    db_connections_active integer,
    db_connections_idle integer,
    db_connections_waiting integer,
    db_connections_max integer,
    db_connections_usage_percent numeric(5,2),
    db_locks_count integer,
    db_deadlocks_count integer,
    db_cache_hit_ratio numeric(5,2),
    db_index_usage_percent numeric(5,2),
    db_table_count integer,
    db_total_rows bigint,
    db_temp_files integer,
    db_temp_bytes bigint,
    db_transaction_rate numeric(10,2),
    db_query_rate numeric(10,2),
    db_slow_queries integer,
    redis_status public.health_status,
    redis_response_time_ms integer,
    redis_memory_used_bytes bigint,
    redis_memory_peak_bytes bigint,
    redis_memory_fragmentation_ratio numeric(5,2),
    redis_connected_clients integer,
    redis_blocked_clients integer,
    redis_commands_processed bigint,
    redis_keyspace_hits bigint,
    redis_keyspace_misses bigint,
    redis_hit_rate numeric(5,2),
    redis_evicted_keys bigint,
    redis_expired_keys bigint,
    redis_cpu_usage_percent numeric(5,2),
    system_platform text,
    system_arch text,
    system_node_version text,
    system_uptime_seconds integer,
    system_memory_total_bytes bigint,
    system_memory_used_bytes bigint,
    system_memory_free_bytes bigint,
    system_memory_usage_percent numeric(5,2),
    system_cpu_count integer,
    system_cpu_model text,
    system_cpu_usage_percent numeric(5,2),
    system_load_avg_1min numeric(10,2),
    system_load_avg_5min numeric(10,2),
    system_load_avg_15min numeric(10,2),
    system_disk_total_bytes bigint,
    system_disk_used_bytes bigint,
    system_disk_free_bytes bigint,
    system_disk_usage_percent numeric(5,2),
    process_memory_rss_bytes bigint,
    process_memory_heap_total_bytes bigint,
    process_memory_heap_used_bytes bigint,
    process_memory_heap_limit_bytes bigint,
    process_memory_external_bytes bigint,
    process_cpu_user_microseconds bigint,
    process_cpu_system_microseconds bigint,
    process_event_loop_lag_ms numeric(10,2),
    api_response_time_avg_ms integer,
    api_response_time_p50_ms integer,
    api_response_time_p95_ms integer,
    api_response_time_p99_ms integer,
    api_requests_total integer,
    api_requests_per_second numeric(10,2),
    api_error_count integer,
    api_error_rate_percent numeric(5,2),
    api_timeout_count integer,
    active_sessions integer,
    active_websockets integer,
    queue_length integer,
    queue_processing_rate numeric(10,2),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_health_metrics OWNER TO postgres;

--
-- Name: system_incidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_incidents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    incident_number text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    severity public.alert_severity NOT NULL,
    status text DEFAULT 'investigating'::text NOT NULL,
    affected_services text[] DEFAULT '{}'::text[] NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    acknowledged_at timestamp with time zone,
    resolved_at timestamp with time zone,
    duration_seconds integer,
    root_cause text,
    resolution_summary text,
    impact_description text,
    affected_users_count integer,
    created_by uuid,
    assigned_to uuid,
    related_alerts uuid[],
    timeline jsonb DEFAULT '[]'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_incidents OWNER TO postgres;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    system_name text DEFAULT 'BuildFlow ERP'::text NOT NULL,
    system_tagline text,
    system_description text,
    logo_url text,
    logo_light_url text,
    logo_dark_url text,
    favicon_url text,
    login_logo_url text,
    email_logo_url text,
    meta_title text,
    meta_description text,
    meta_keywords text[],
    og_image_url text,
    og_title text,
    og_description text,
    twitter_card_type public.twitter_card_type DEFAULT 'summary_large_image'::public.twitter_card_type,
    twitter_site text,
    twitter_creator text,
    google_analytics_id text,
    google_tag_manager_id text,
    facebook_pixel_id text,
    custom_tracking_code text,
    custom_head_scripts text,
    custom_body_scripts text,
    ad_network_enabled boolean DEFAULT false NOT NULL,
    ad_network_code text,
    ad_placement_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    support_email text,
    support_phone text,
    support_address jsonb,
    social_links jsonb DEFAULT '{}'::jsonb NOT NULL,
    legal_links jsonb DEFAULT '{}'::jsonb NOT NULL,
    email_provider public.email_provider_type DEFAULT 'smtp'::public.email_provider_type,
    smtp_host text,
    smtp_port integer DEFAULT 587,
    smtp_user text,
    smtp_password_encrypted text,
    smtp_from_email text,
    smtp_from_name text,
    smtp_use_tls boolean DEFAULT true NOT NULL,
    smtp_use_ssl boolean DEFAULT false NOT NULL,
    sendgrid_api_key_encrypted text,
    sendgrid_from_email text,
    sendgrid_from_name text,
    mailgun_api_key_encrypted text,
    mailgun_domain text,
    mailgun_region text DEFAULT 'us'::text,
    aws_ses_region text,
    aws_ses_access_key_encrypted text,
    aws_ses_secret_key_encrypted text,
    aws_ses_from_email text,
    aws_ses_from_name text,
    resend_api_key_encrypted text,
    resend_from_email text,
    resend_from_name text,
    postmark_api_key_encrypted text,
    postmark_from_email text,
    postmark_from_name text,
    email_test_mode boolean DEFAULT false NOT NULL,
    email_test_recipient text,
    password_min_length integer DEFAULT 8 NOT NULL,
    password_max_length integer DEFAULT 128 NOT NULL,
    password_require_uppercase boolean DEFAULT true NOT NULL,
    password_require_lowercase boolean DEFAULT true NOT NULL,
    password_require_numbers boolean DEFAULT true NOT NULL,
    password_require_symbols boolean DEFAULT false NOT NULL,
    password_expiry_days integer,
    password_history_count integer DEFAULT 5,
    session_timeout_minutes integer DEFAULT 60 NOT NULL,
    session_absolute_timeout_hours integer DEFAULT 24,
    max_concurrent_sessions integer DEFAULT 5,
    max_login_attempts integer DEFAULT 5 NOT NULL,
    lockout_duration_minutes integer DEFAULT 30 NOT NULL,
    progressive_lockout boolean DEFAULT true NOT NULL,
    require_email_verification boolean DEFAULT true NOT NULL,
    email_verification_expires_hours integer DEFAULT 24 NOT NULL,
    enable_two_factor boolean DEFAULT false NOT NULL,
    force_two_factor_for_roles text[] DEFAULT '{}'::text[],
    enable_captcha boolean DEFAULT false NOT NULL,
    captcha_provider text DEFAULT 'recaptcha_v3'::text,
    captcha_site_key text,
    captcha_secret_key_encrypted text,
    captcha_threshold numeric(3,2) DEFAULT 0.5,
    enable_rate_limiting boolean DEFAULT true NOT NULL,
    rate_limit_requests_per_minute integer DEFAULT 60 NOT NULL,
    rate_limit_burst_size integer DEFAULT 100,
    ip_whitelist inet[],
    ip_blacklist inet[],
    enable_ip_geolocation boolean DEFAULT false NOT NULL,
    blocked_countries text[],
    allowed_countries text[],
    file_storage_provider public.storage_provider_type DEFAULT 'local'::public.storage_provider_type NOT NULL,
    file_storage_path text DEFAULT '/app/storage'::text,
    max_file_size_bytes bigint DEFAULT 10485760 NOT NULL,
    max_total_storage_bytes bigint,
    allowed_mime_types text[] DEFAULT '{image/jpeg,image/png,image/gif,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/zip}'::text[],
    blocked_mime_types text[] DEFAULT '{application/x-executable,application/x-msdos-program}'::text[],
    enable_virus_scanning boolean DEFAULT false NOT NULL,
    virus_scan_provider text,
    aws_s3_bucket text,
    aws_s3_region text,
    aws_s3_access_key_encrypted text,
    aws_s3_secret_key_encrypted text,
    aws_s3_public_url text,
    cdn_enabled boolean DEFAULT false NOT NULL,
    cdn_url text,
    api_enabled boolean DEFAULT true NOT NULL,
    api_rate_limit_enabled boolean DEFAULT true NOT NULL,
    api_rate_limit_requests_per_minute integer DEFAULT 100,
    api_timeout_seconds integer DEFAULT 30 NOT NULL,
    api_max_payload_size_bytes integer DEFAULT 1048576,
    enable_api_documentation boolean DEFAULT true NOT NULL,
    api_documentation_url text,
    enable_cors boolean DEFAULT true NOT NULL,
    cors_allowed_origins text[],
    cors_allowed_methods text[] DEFAULT '{GET,POST,PUT,DELETE,PATCH}'::text[],
    cors_allowed_headers text[] DEFAULT '{Content-Type,Authorization}'::text[],
    cors_max_age_seconds integer DEFAULT 86400,
    log_level public.log_level_type DEFAULT 'info'::public.log_level_type NOT NULL,
    enable_audit_logging boolean DEFAULT true NOT NULL,
    log_retention_days integer DEFAULT 90 NOT NULL,
    log_sensitive_data boolean DEFAULT false NOT NULL,
    enable_error_tracking boolean DEFAULT false NOT NULL,
    sentry_dsn_encrypted text,
    sentry_environment text,
    sentry_sample_rate numeric(3,2) DEFAULT 1.0,
    enable_performance_monitoring boolean DEFAULT false NOT NULL,
    performance_sample_rate numeric(3,2) DEFAULT 0.1,
    enable_auto_backup boolean DEFAULT true NOT NULL,
    backup_schedule text DEFAULT '0 2 * * *'::text,
    backup_retention_days integer DEFAULT 30 NOT NULL,
    backup_storage_provider public.storage_provider_type DEFAULT 'local'::public.storage_provider_type,
    backup_storage_path text DEFAULT '/app/backups'::text,
    backup_encryption_enabled boolean DEFAULT true NOT NULL,
    backup_compression_enabled boolean DEFAULT true NOT NULL,
    maintenance_mode boolean DEFAULT false NOT NULL,
    maintenance_message text,
    maintenance_allowed_ips inet[],
    maintenance_start_time timestamp with time zone,
    maintenance_end_time timestamp with time zone,
    default_language text DEFAULT 'en'::text NOT NULL,
    available_languages text[] DEFAULT '{en}'::text[],
    default_timezone text DEFAULT 'UTC'::text NOT NULL,
    default_currency_code text DEFAULT 'USD'::text,
    default_date_format text DEFAULT 'YYYY-MM-DD'::text,
    default_time_format text DEFAULT 'HH:mm:ss'::text,
    enable_registration boolean DEFAULT true NOT NULL,
    registration_requires_approval boolean DEFAULT false NOT NULL,
    registration_auto_verify_email boolean DEFAULT false NOT NULL,
    default_user_role text,
    enable_invitations boolean DEFAULT true NOT NULL,
    invitation_expiry_hours integer DEFAULT 72,
    terms_version text,
    terms_last_updated timestamp with time zone,
    privacy_version text,
    privacy_last_updated timestamp with time zone,
    cookie_consent_enabled boolean DEFAULT true NOT NULL,
    gdpr_compliant boolean DEFAULT true NOT NULL,
    data_retention_days integer,
    enable_data_export boolean DEFAULT true NOT NULL,
    enable_account_deletion boolean DEFAULT true NOT NULL,
    system_version text,
    deployment_environment text DEFAULT 'production'::text,
    feature_flags jsonb DEFAULT '{}'::jsonb NOT NULL,
    custom_settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: system_sla_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_sla_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_date timestamp without time zone NOT NULL,
    service_name text NOT NULL,
    uptime_percentage numeric(5,2) NOT NULL,
    downtime_minutes integer DEFAULT 0 NOT NULL,
    total_requests bigint DEFAULT 0 NOT NULL,
    successful_requests bigint DEFAULT 0 NOT NULL,
    failed_requests bigint DEFAULT 0 NOT NULL,
    avg_response_time_ms numeric(10,2),
    p95_response_time_ms numeric(10,2),
    p99_response_time_ms numeric(10,2),
    incident_count integer DEFAULT 0 NOT NULL,
    mttr_minutes numeric(10,2),
    mttd_minutes numeric(10,2),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_sla_metrics OWNER TO postgres;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ticket_number text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    agency_id uuid,
    user_id uuid,
    assigned_to uuid,
    department text,
    page_url text,
    screenshot_url text,
    console_logs jsonb,
    error_details jsonb,
    browser_info jsonb,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone
);


ALTER TABLE public.tickets OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    agency_id uuid,
    role public.user_role NOT NULL,
    custom_role_name text,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    valid_until timestamp with time zone,
    assigned_by uuid,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    refresh_token_hash text,
    ip_address inet,
    user_agent text,
    device_fingerprint text,
    expires_at timestamp with time zone NOT NULL,
    refresh_expires_at timestamp with time zone,
    last_activity_at timestamp with time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    revoked_at timestamp with time zone,
    revoked_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    email_normalized text NOT NULL,
    password_hash text NOT NULL,
    email_confirmed boolean DEFAULT false NOT NULL,
    email_confirmed_at timestamp with time zone,
    phone text,
    phone_verified boolean DEFAULT false NOT NULL,
    phone_verified_at timestamp with time zone,
    status public.user_status DEFAULT 'active'::public.user_status NOT NULL,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    password_changed_at timestamp with time zone,
    must_change_password boolean DEFAULT false NOT NULL,
    terms_accepted_at timestamp with time zone,
    terms_version text,
    privacy_accepted_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    last_sign_in_ip inet,
    sign_in_count integer DEFAULT 0 NOT NULL,
    raw_user_meta_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: postgres
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	8ddeca9e8f4285b80eee280c7b3d04662e2a57ab0b7d1877534a0c6bf1a8fc95	1771390648762
\.


--
-- Data for Name: agencies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agencies (id, name, domain, database_name, owner_user_id, subscription_plan, status, max_users, max_storage_gb, features, settings, metadata, contact_email, contact_phone, billing_email, address, tax_id, subscription_starts_at, subscription_ends_at, trial_ends_at, is_active, deleted_at, created_at, updated_at) FROM stdin;
e5050a77-e022-4ad0-b3ec-a9d409d2d28b	Hamilton Oneil	quominimeumidculpaeaomnisaspernaturametvelelitvol.oru.erp	agency_quominimeumidculpaeaomnisaspernaturametvelelitvol_db	b694851e-24a2-4e91-a0a4-8d2a0d12d200	professional	pending	50	10	[]	{}	{}	ipsummaioreslabor.nesciuntsintaliqu@quominimeumidculpaeaomnisaspernaturametvelelitvol.dev	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-18 12:53:23.782035+00	2026-02-18 12:53:23.782035+00
d20e3222-a262-43d4-ad8e-b9bf879b2a61	easyio	easyio.oru.erp	agency_easyio_db	eb06b795-c264-4686-bc7d-fe65126d2dca	professional	pending	50	10	[]	{}	{}	burhan.ali@easyio.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-18 12:54:07.539455+00	2026-02-18 12:54:07.539455+00
ab8c0f28-f423-4719-99dc-d7e3a2479848	Katelyn Madden	sitinprovidentvoluptateaperiamoditexconsequaturaut.oru.erp	agency_sitinprovidentvoluptateaperiamoditexconsequaturaut_db	83c942d9-4841-4743-8953-c092d2890773	professional	pending	50	10	[]	{}	{}	utipsumnostrumli.ipsumdolorequodod@sitinprovidentvoluptateaperiamoditexconsequaturaut.agency	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-18 15:05:38.146088+00	2026-02-18 15:05:38.146088+00
dc1fd47e-137f-489b-832b-149c653dc7bc	Blaine Goodwin	laborumillumaliasanimiquiqui.oru.erp	agency_laborumillumaliasanimiquiqui_db	5dbafdc1-58cb-4902-80a1-955b8c4a1409	professional	pending	50	10	[]	{}	{}	sedprovidentnemo.harumfugitaliquid@laborumillumaliasanimiquiqui.co	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-18 15:48:23.819096+00	2026-02-18 15:48:23.819096+00
2050121e-65f8-445e-8fd2-b888908999c2	Wendy Waller	quisdignissimosnonitaqueducimusperspiciatiscorrupti.oru.erp	agency_quisdignissimosnonitaqueducimusperspiciatiscorrupti_db	c64e501c-2202-443b-908e-88c7132b75c8	professional	pending	50	10	[]	{}	{}	aperiammollitiaut.autemeaconsequat@quisdignissimosnonitaqueducimusperspiciatiscorrupti.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-18 16:23:33.868719+00	2026-02-18 16:23:33.868719+00
e4d3d4c2-2761-4ee7-9b48-cb709ecc3abc	Cecilia Donovan	voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu.oru.erp	agency_voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu_db	31fe0044-e19c-49a3-acb1-383cfcb228de	professional	pending	50	10	[]	{}	{}	ipsumatqueexceptur.commodolaborumlab@voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu.tech	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-18 16:42:46.137517+00	2026-02-18 16:42:46.137517+00
5fb30192-062e-42e4-89da-1d23c1e93ebc	gmail	gmail.oru.erp	agency_gmail_db	d2f437f9-a012-4d93-845d-31b537dedd0b	professional	active	50	10	[]	{}	{}	burhan.ali@gmail.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-18 16:50:33.812447+00	2026-02-18 16:50:36.165+00
d3a0c021-5994-41ac-b427-53bf9fa16cc2	Irene Bray	aubreybaxter.oru.erp	agency_aubreybaxter_db	19189810-fe9e-4ac2-b440-5ccb1427a08b	professional	active	50	10	[]	{}	{}	aliquiplaborissunt.blanditiisetsitdo@aubreybaxter.net	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-18 17:09:13.992137+00	2026-02-18 17:09:15.88+00
b654008a-8267-4dc0-80b4-cd12bba83e60	Shelley Nicholson	amylevy.oru.erp	agency_amylevy_db	a1981e17-e9aa-4408-9336-8c1a091b683a	professional	active	50	10	[]	{}	{}	eteuevenietadipi.distinctioaccusant@amylevy.app	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-18 17:21:37.927352+00	2026-02-18 17:21:40.485+00
8dd0b47f-df36-4a23-9b6a-122eb46f2565	mob	mob.oru.erp	agency_mob_db	fa25e6e1-5bb2-4363-8958-b610dcb3ccff	professional	active	50	10	[]	{}	{}	burhan.ali@mob.app	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-19 02:07:46.668069+00	2026-02-19 02:07:48.87+00
235df6a1-77ee-4a3c-9c40-ab4e4e7ded47	facebook	facebook.oru.erp	agency_facebook_db	abf06f11-bf9d-41d3-a986-9950e361e6da	professional	active	50	10	[]	{}	{}	burhan.ali@facebook.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-19 02:23:01.456128+00	2026-02-19 02:23:03.404+00
78353732-c3e4-4f1c-81a5-c24b52fb7b56	evo	evo.oru.erp	agency_evo_db	1d15d6d0-0e40-4556-b92d-fe0164ed4aaf	professional	active	50	10	[]	{}	{}	main.admin@evo.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-19 02:47:18.844354+00	2026-02-19 02:47:21.941+00
f0ef09a0-813e-41d8-8cab-543a0e180610	mouse	mouse.oru.erp	agency_mouse_db	47ca540b-9e2f-441e-86c6-41ea8e9f0b74	professional	pending	50	10	[]	{}	{}	mou.se@mouse.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-19 03:12:36.796328+00	2026-02-19 03:12:36.796328+00
8eb76b16-f6fa-4a8f-aa08-87fe319b30a3	Joelle Ferrell	jenniferlevy.oru.erp	agency_jenniferlevy_db	dbcdae49-502d-4877-9a2d-02114259dc63	professional	pending	50	10	[]	{}	{}	uteaenimnullacup.temporsitinlorem@jenniferlevy.app	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-19 03:36:40.809376+00	2026-02-19 03:36:40.809376+00
02af1694-1ad9-4945-ac72-34b3f4757dd1	Chaney Sosa	serenahahn.oru.erp	agency_serenahahn_db	7ab7da08-1947-4ab4-9c41-0fcaf5190d09	professional	pending	50	10	[]	{}	{}	temporaexcepteurfu.exercitationconsequ@serenahahn.io	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-19 03:41:43.938903+00	2026-02-19 03:41:43.938903+00
47531588-5211-461e-a5f5-858eba491f87	Kaye Witt	ashtonduke.oru.erp	agency_ashtonduke_db	322c3b0c-d151-4d0a-8f1c-99f6192ae39b	professional	pending	50	10	[]	{}	{}	nisiveritatisquia.consequuntursitvel@ashtonduke.io	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-19 04:37:46.09907+00	2026-02-19 04:37:46.09907+00
8474c1b2-37db-493a-b6dd-ff294fcfd7de	Wynne Hamilton	vernondoyle.oru.erp	agency_vernondoyle_db	712ce548-5fed-4d35-87b4-6f6ef540ec3e	professional	pending	50	10	[]	{}	{}	molestiaenisieums.voluptatumremiste@vernondoyle.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-19 14:26:43.348136+00	2026-02-19 14:26:43.348136+00
dd77aa86-20f5-4c5b-b956-61eb58c31da7	Dolorem illo quaerat	inaspernaturodiod.oru.erp	agency_inaspernaturodiod_db	29ddab1d-002b-4022-9f87-6816293a5f8e	trial	pending	50	10	[]	{}	{}	jyly@mailinator.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-20 01:45:37.930134+00	2026-02-20 01:45:37.930134+00
39563ba1-3fb9-402f-8179-67a7aee25434	Garth Bowman	eosduisinventore.oru.erp	agency_eosduisinventore_db	e013de97-fcb4-4423-9b24-7070b8ef9b1f	trial	pending	50	10	[]	{}	{}	kezafor@mailinator.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-20 02:07:42.481366+00	2026-02-20 02:07:42.481366+00
9c51c25e-d6aa-432d-afca-cc10cd8f3da5	Ocean Welch	temporibusenimexpe.oru.erp	agency_temporibusenimexpe_db	30ead45c-2658-42f4-9406-3f3f27d0b545	trial	pending	50	10	[]	{}	{}	97patrizia@virgilian.com	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-02-20 02:08:36.431277+00	2026-02-20 02:08:36.431277+00
\.


--
-- Data for Name: agency_page_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agency_page_assignments (id, agency_id, page_id, status, cost_override, billing_cycle_override, discount_percent, is_trial, trial_started_at, trial_ends_at, assigned_at, assigned_by, activated_at, suspended_at, suspended_by, suspension_reason, expires_at, auto_renew, usage_count, last_accessed_at, custom_quota, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agency_page_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agency_page_requests (id, agency_id, page_id, requested_by, status, priority, reason, business_justification, expected_usage, expected_users, budget_allocated, desired_start_date, reviewed_by, reviewed_at, review_notes, approved_cost, rejection_reason, auto_approved, attachments, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agency_provisioning_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agency_provisioning_jobs (id, idempotency_key, status, domain, database_name, agency_name, owner_email, subscription_plan, requested_by, payload, validation_errors, progress_percentage, current_step, steps_completed, steps_total, result, agency_id, error_message, error_code, error_details, stack_trace, retry_count, max_retries, next_retry_at, priority, timeout_seconds, worker_id, worker_hostname, started_at, completed_at, cancelled_at, cancelled_by, cancellation_reason, estimated_completion_at, metadata, created_at, updated_at) FROM stdin;
a1af1d39-dc31-4750-8078-02bac4c00933	\N	failed	mouse.oru.erp	agency_mouse_db	mouse	mou.se@mouse.com	professional	47ca540b-9e2f-441e-86c6-41ea8e9f0b74	{"plan": "professional", "address": {"country": "IN"}, "lastName": "se", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "mou", "subdomain": "mouse", "adminEmail": "mou.se@mouse.com", "companyName": "mouse", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	f0ef09a0-813e-41d8-8cab-543a0e180610	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 03:16:54.073+00	2026-02-19 03:16:54.114+00	\N	\N	\N	\N	{}	2026-02-19 03:16:50.808372+00	2026-02-19 03:16:50.808372+00
2a7425a9-0862-4d00-855b-ddc494fb2f49	\N	failed	jenniferlevy.oru.erp	agency_jenniferlevy_db	Joelle Ferrell	uteaenimnullacup.temporsitinlorem@jenniferlevy.app	professional	dbcdae49-502d-4877-9a2d-02114259dc63	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ea enim nulla cup Tempor sit in lorem", "maxUsers": 10, "metadata": {"industry": "marketing", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Ut", "subdomain": "jenniferlevy", "adminEmail": "uteaenimnullacup.temporsitinlorem@jenniferlevy.app", "companyName": "Joelle Ferrell", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	8eb76b16-f6fa-4a8f-aa08-87fe319b30a3	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 03:37:37.395+00	2026-02-19 03:37:37.432+00	\N	\N	\N	\N	{}	2026-02-19 03:37:33.957727+00	2026-02-19 03:37:33.957727+00
636b8c89-b2ec-4d6e-870b-9dff5437c491	\N	failed	easyio.oru.erp	agency_easyio_db	easyio	burhan.ali@easyio.com	professional	eb06b795-c264-4686-bc7d-fe65126d2dca	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ali", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "burhan", "subdomain": "easyio", "adminEmail": "burhan.ali@easyio.com", "companyName": "easyio"}	\N	50	\N	{}	\N	\N	d20e3222-a262-43d4-ad8e-b9bf879b2a61		\N	{"step": "provisioning"}	AggregateError [ECONNREFUSED]: \n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async PgDialect.migrate (file:///app/node_modules/drizzle-orm/pg-core/dialect.js:54:5)\n    at async migrate (file:///app/node_modules/drizzle-orm/node-postgres/migrator.js:4:3)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:52:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	94f2cdd6784d-19	\N	2026-02-18 12:54:11.159+00	2026-02-18 12:54:11.177+00	\N	\N	\N	\N	{}	2026-02-18 12:54:07.546153+00	2026-02-18 12:54:07.546153+00
8484902b-fb1b-4c7c-a858-c646d8bd5373	\N	failed	vernondoyle.oru.erp	agency_vernondoyle_db	Wynne Hamilton	molestiaenisieums.voluptatumremiste@vernondoyle.com	professional	712ce548-5fed-4d35-87b4-6f6ef540ec3e	{"plan": "professional", "address": {"country": "AU"}, "lastName": "nisi eum s Voluptatum rem iste", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Molestiae", "subdomain": "vernondoyle", "adminEmail": "molestiaenisieums.voluptatumremiste@vernondoyle.com", "companyName": "Wynne Hamilton", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	8474c1b2-37db-493a-b6dd-ff294fcfd7de	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 14:43:27.509+00	2026-02-19 14:43:27.553+00	\N	\N	\N	\N	{}	2026-02-19 14:43:22.857958+00	2026-02-19 14:43:22.857958+00
12609fa4-4206-404a-8c3e-06dddc5935a7	\N	failed	quominimeumidculpaeaomnisaspernaturametvelelitvol.oru.erp	agency_quominimeumidculpaeaomnisaspernaturametvelelitvol_db	Hamilton Oneil	ipsummaioreslabor.nesciuntsintaliqu@quominimeumidculpaeaomnisaspernaturametvelelitvol.dev	professional	b694851e-24a2-4e91-a0a4-8d2a0d12d200	{"plan": "professional", "address": {"country": "IN"}, "lastName": "maiores labor Nesciunt sint aliqu", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Ipsum", "subdomain": "quominimeumidculpaeaomnisaspernaturametvelelitvol", "adminEmail": "ipsummaioreslabor.nesciuntsintaliqu@quominimeumidculpaeaomnisaspernaturametvelelitvol.dev", "companyName": "Hamilton Oneil"}	\N	50	\N	{}	\N	\N	e5050a77-e022-4ad0-b3ec-a9d409d2d28b		\N	{"step": "provisioning"}	AggregateError [ECONNREFUSED]: \n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async PgDialect.migrate (file:///app/node_modules/drizzle-orm/pg-core/dialect.js:54:5)\n    at async migrate (file:///app/node_modules/drizzle-orm/node-postgres/migrator.js:4:3)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:52:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	94f2cdd6784d-19	\N	2026-02-18 12:53:27.369+00	2026-02-18 12:53:27.383+00	\N	\N	\N	\N	{}	2026-02-18 12:53:23.79293+00	2026-02-18 12:53:23.79293+00
65e81a9d-3f6d-4ee1-a2dc-edabce2c10e5	\N	failed	voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu.oru.erp	agency_voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu_db	Cecilia Donovan	ipsumatqueexceptur.commodolaborumlab@voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu.tech	professional	31fe0044-e19c-49a3-acb1-383cfcb228de	{"plan": "professional", "address": {"country": "IN"}, "lastName": "atque exceptur Commodo laborum Lab", "maxUsers": 10, "metadata": {"industry": "creative", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Ipsum", "subdomain": "voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu", "adminEmail": "ipsumatqueexceptur.commodolaborumlab@voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu.tech", "companyName": "Cecilia Donovan", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	e4d3d4c2-2761-4ee7-9b48-cb709ecc3abc		\N	{"step": "provisioning"}	AggregateError [ECONNREFUSED]: \n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async PgDialect.migrate (file:///app/node_modules/drizzle-orm/pg-core/dialect.js:54:5)\n    at async migrate (file:///app/node_modules/drizzle-orm/node-postgres/migrator.js:4:3)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:56:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	2663cda2cd83-18	\N	2026-02-18 16:42:49.781+00	2026-02-18 16:42:49.8+00	\N	\N	\N	\N	{}	2026-02-18 16:42:46.143573+00	2026-02-18 16:42:46.143573+00
147545ed-4dac-4528-b237-1f6e71ecde17	\N	failed	temporibusenimexpe.oru.erp	agency_temporibusenimexpe_db	Ocean Welch	97patrizia@virgilian.com	trial	30ead45c-2658-42f4-9406-3f3f27d0b545	{"plan": "trial", "address": {}, "lastName": "Forbes", "maxUsers": 10, "metadata": {}, "password": "***", "settings": {}, "firstName": "Victor", "subdomain": "temporibusenimexpe", "adminEmail": "97patrizia@virgilian.com", "companyName": "Ocean Welch", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	9c51c25e-d6aa-432d-afca-cc10cd8f3da5	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-20 02:08:44.359+00	2026-02-20 02:08:44.393+00	\N	\N	\N	\N	{}	2026-02-20 02:08:36.436147+00	2026-02-20 02:08:36.436147+00
3288775a-ce4b-44b9-bbaf-e06d210fdd74	\N	failed	inaspernaturodiod.oru.erp	agency_inaspernaturodiod_db	Dolorem illo quaerat	jyly@mailinator.com	trial	29ddab1d-002b-4022-9f87-6816293a5f8e	{"plan": "trial", "address": {}, "lastName": "deserunt incidun", "maxUsers": 10, "metadata": {"industry": "Marketing & Advertising", "companySize": "1000+"}, "password": "***", "settings": {}, "firstName": "Nam", "subdomain": "inaspernaturodiod", "adminEmail": "jyly@mailinator.com", "companyName": "Dolorem illo quaerat", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	dd77aa86-20f5-4c5b-b956-61eb58c31da7	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-20 01:45:42.744+00	2026-02-20 01:45:42.831+00	\N	\N	\N	\N	{}	2026-02-20 01:45:37.935635+00	2026-02-20 01:45:37.935635+00
6d0c1a24-65fd-4309-9baa-3fca9c59aaa5	\N	failed	jenniferlevy.oru.erp	agency_jenniferlevy_db	Joelle Ferrell	uteaenimnullacup.temporsitinlorem@jenniferlevy.app	professional	dbcdae49-502d-4877-9a2d-02114259dc63	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ea enim nulla cup Tempor sit in lorem", "maxUsers": 10, "metadata": {"industry": "marketing", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Ut", "subdomain": "jenniferlevy", "adminEmail": "uteaenimnullacup.temporsitinlorem@jenniferlevy.app", "companyName": "Joelle Ferrell", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	8eb76b16-f6fa-4a8f-aa08-87fe319b30a3	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 03:41:24.519+00	2026-02-19 03:41:24.569+00	\N	\N	\N	\N	{}	2026-02-19 03:41:21.113324+00	2026-02-19 03:41:21.113324+00
7613ac5e-1efc-48dd-96ff-0f20f3d4bc4b	\N	completed	gmail.oru.erp	agency_gmail_db	gmail	burhan.ali@gmail.com	professional	d2f437f9-a012-4d93-845d-31b537dedd0b	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ali", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "burhan", "subdomain": "gmail", "adminEmail": "burhan.ali@gmail.com", "companyName": "gmail", "maxStorageGB": 10}	\N	100	\N	{}	\N	{"dbName": "agency_gmail_db", "success": true}	5fb30192-062e-42e4-89da-1d23c1e93ebc	\N	\N	\N	\N	0	3	\N	5	300	83ff1b2c9907-18	\N	2026-02-18 16:50:33.858+00	2026-02-18 16:50:36.177+00	\N	\N	\N	\N	{}	2026-02-18 16:50:33.818426+00	2026-02-18 16:50:33.818426+00
b85968b1-22f6-4e3f-8416-9c9ac3250289	\N	failed	sitinprovidentvoluptateaperiamoditexconsequaturaut.oru.erp	agency_sitinprovidentvoluptateaperiamoditexconsequaturaut_db	Katelyn Madden	utipsumnostrumli.ipsumdolorequodod@sitinprovidentvoluptateaperiamoditexconsequaturaut.agency	professional	83c942d9-4841-4743-8953-c092d2890773	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ipsum nostrum li Ipsum dolore quod od", "maxUsers": 10, "metadata": {"industry": "marketing", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Ut", "subdomain": "sitinprovidentvoluptateaperiamoditexconsequaturaut", "adminEmail": "utipsumnostrumli.ipsumdolorequodod@sitinprovidentvoluptateaperiamoditexconsequaturaut.agency", "companyName": "Katelyn Madden"}	\N	50	\N	{}	\N	\N	ab8c0f28-f423-4719-99dc-d7e3a2479848		\N	{"step": "provisioning"}	AggregateError [ECONNREFUSED]: \n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async PgDialect.migrate (file:///app/node_modules/drizzle-orm/pg-core/dialect.js:54:5)\n    at async migrate (file:///app/node_modules/drizzle-orm/node-postgres/migrator.js:4:3)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:52:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	a2818791e2de-18	\N	2026-02-18 15:05:42.613+00	2026-02-18 15:05:42.632+00	\N	\N	\N	\N	{}	2026-02-18 15:05:38.158255+00	2026-02-18 15:05:38.158255+00
8639caa1-05b8-4c6b-bf6c-bf841bff0bc3	\N	completed	mob.oru.erp	agency_mob_db	mob	burhan.ali@mob.app	professional	fa25e6e1-5bb2-4363-8958-b610dcb3ccff	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ali", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "burhan", "subdomain": "mob", "adminEmail": "burhan.ali@mob.app", "companyName": "mob", "maxStorageGB": 10}	\N	100	\N	{}	\N	{"agency": {"id": "8dd0b47f-df36-4a23-9b6a-122eb46f2565", "name": "mob", "taxId": null, "domain": "mob.oru.erp", "status": "active", "address": null, "features": [], "isActive": true, "maxUsers": 50, "metadata": {}, "settings": {}, "createdAt": "2026-02-19T02:07:46.668Z", "deletedAt": null, "updatedAt": "2026-02-19T02:07:48.870Z", "ownerUserId": "fa25e6e1-5bb2-4363-8958-b610dcb3ccff", "trialEndsAt": null, "billingEmail": null, "contactEmail": "burhan.ali@mob.app", "contactPhone": null, "databaseName": "agency_mob_db", "maxStorageGB": 10, "subscriptionPlan": "professional", "subscriptionEndsAt": null, "subscriptionStartsAt": null}, "dbName": "agency_mob_db", "success": true}	8dd0b47f-df36-4a23-9b6a-122eb46f2565	\N	\N	\N	\N	0	3	\N	5	300	80fd16fb4e5e-18	\N	2026-02-19 02:07:46.737+00	2026-02-19 02:07:48.887+00	\N	\N	\N	\N	{}	2026-02-19 02:07:46.676858+00	2026-02-19 02:07:46.676858+00
b43c1a47-2469-4ac2-a628-8e831529649b	\N	completed	aubreybaxter.oru.erp	agency_aubreybaxter_db	Irene Bray	aliquiplaborissunt.blanditiisetsitdo@aubreybaxter.net	professional	19189810-fe9e-4ac2-b440-5ccb1427a08b	{"plan": "professional", "address": {"country": "IN"}, "lastName": "laboris sunt Blanditiis et sit do", "maxUsers": 10, "metadata": {"industry": "legal", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Aliquip", "subdomain": "aubreybaxter", "adminEmail": "aliquiplaborissunt.blanditiisetsitdo@aubreybaxter.net", "companyName": "Irene Bray", "maxStorageGB": 10}	\N	100	\N	{}	\N	{"agency": {"id": "d3a0c021-5994-41ac-b427-53bf9fa16cc2", "name": "Irene Bray", "taxId": null, "domain": "aubreybaxter.oru.erp", "status": "active", "address": null, "features": [], "isActive": true, "maxUsers": 50, "metadata": {}, "settings": {}, "createdAt": "2026-02-18T17:09:13.992Z", "deletedAt": null, "updatedAt": "2026-02-18T17:09:15.880Z", "ownerUserId": "19189810-fe9e-4ac2-b440-5ccb1427a08b", "trialEndsAt": null, "billingEmail": null, "contactEmail": "aliquiplaborissunt.blanditiisetsitdo@aubreybaxter.net", "contactPhone": null, "databaseName": "agency_aubreybaxter_db", "maxStorageGB": 10, "subscriptionPlan": "professional", "subscriptionEndsAt": null, "subscriptionStartsAt": null}, "dbName": "agency_aubreybaxter_db", "success": true}	d3a0c021-5994-41ac-b427-53bf9fa16cc2	\N	\N	\N	\N	0	3	\N	5	300	4154e806855a-18	\N	2026-02-18 17:09:14.048+00	2026-02-18 17:09:15.901+00	\N	\N	\N	\N	{}	2026-02-18 17:09:14.001095+00	2026-02-18 17:09:14.001095+00
253a0b92-c7ab-480b-b883-283c701bbe68	\N	completed	facebook.oru.erp	agency_facebook_db	facebook	burhan.ali@facebook.com	professional	abf06f11-bf9d-41d3-a986-9950e361e6da	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ali", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "burhan", "subdomain": "facebook", "adminEmail": "burhan.ali@facebook.com", "companyName": "facebook", "maxStorageGB": 10}	\N	100	\N	{}	\N	{"agency": {"id": "235df6a1-77ee-4a3c-9c40-ab4e4e7ded47", "name": "facebook", "taxId": null, "domain": "facebook.oru.erp", "status": "active", "address": null, "features": [], "isActive": true, "maxUsers": 50, "metadata": {}, "settings": {}, "createdAt": "2026-02-19T02:23:01.456Z", "deletedAt": null, "updatedAt": "2026-02-19T02:23:03.404Z", "ownerUserId": "abf06f11-bf9d-41d3-a986-9950e361e6da", "trialEndsAt": null, "billingEmail": null, "contactEmail": "burhan.ali@facebook.com", "contactPhone": null, "databaseName": "agency_facebook_db", "maxStorageGB": 10, "subscriptionPlan": "professional", "subscriptionEndsAt": null, "subscriptionStartsAt": null}, "dbName": "agency_facebook_db", "success": true}	235df6a1-77ee-4a3c-9c40-ab4e4e7ded47	\N	\N	\N	\N	0	3	\N	5	300	6630ba966cd4-17	\N	2026-02-19 02:23:01.522+00	2026-02-19 02:23:03.409+00	\N	\N	\N	\N	{}	2026-02-19 02:23:01.462936+00	2026-02-19 02:23:01.462936+00
c01c163b-51aa-4748-ac2d-5584751409bf	\N	failed	vernondoyle.oru.erp	agency_vernondoyle_db	Wynne Hamilton	molestiaenisieums.voluptatumremiste@vernondoyle.com	professional	712ce548-5fed-4d35-87b4-6f6ef540ec3e	{"plan": "professional", "address": {"country": "AU"}, "lastName": "nisi eum s Voluptatum rem iste", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Molestiae", "subdomain": "vernondoyle", "adminEmail": "molestiaenisieums.voluptatumremiste@vernondoyle.com", "companyName": "Wynne Hamilton", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	8474c1b2-37db-493a-b6dd-ff294fcfd7de	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-20 02:15:43.823+00	2026-02-20 02:15:43.852+00	\N	\N	\N	\N	{}	2026-02-20 02:15:40.316369+00	2026-02-20 02:15:40.316369+00
0b600a16-3430-4fab-a3ec-21f349d4e3bc	\N	failed	serenahahn.oru.erp	agency_serenahahn_db	Chaney Sosa	temporaexcepteurfu.exercitationconsequ@serenahahn.io	professional	7ab7da08-1947-4ab4-9c41-0fcaf5190d09	{"plan": "professional", "address": {"country": "IN"}, "lastName": "excepteur fu Exercitation consequ", "maxUsers": 10, "metadata": {"industry": "education", "companySize": "2-10", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Tempora", "subdomain": "serenahahn", "adminEmail": "temporaexcepteurfu.exercitationconsequ@serenahahn.io", "companyName": "Chaney Sosa", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	02af1694-1ad9-4945-ac72-34b3f4757dd1	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 03:41:48.947+00	2026-02-19 03:41:49.007+00	\N	\N	\N	\N	{}	2026-02-19 03:41:43.944145+00	2026-02-19 03:41:43.944145+00
67083a83-37fb-4fbd-bd98-ccdddc3977ac	\N	failed	eosduisinventore.oru.erp	agency_eosduisinventore_db	Garth Bowman	kezafor@mailinator.com	trial	e013de97-fcb4-4423-9b24-7070b8ef9b1f	{"plan": "trial", "address": {}, "lastName": "Wilkins", "maxUsers": 10, "metadata": {}, "password": "***", "settings": {}, "firstName": "Eugenia", "subdomain": "eosduisinventore", "adminEmail": "kezafor@mailinator.com", "companyName": "Garth Bowman", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	39563ba1-3fb9-402f-8179-67a7aee25434	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-20 02:07:46.95+00	2026-02-20 02:07:46.978+00	\N	\N	\N	\N	{}	2026-02-20 02:07:42.486037+00	2026-02-20 02:07:42.486037+00
616fe3b0-13e6-4f28-a50b-4a706501a353	\N	failed	laborumillumaliasanimiquiqui.oru.erp	agency_laborumillumaliasanimiquiqui_db	Blaine Goodwin	sedprovidentnemo.harumfugitaliquid@laborumillumaliasanimiquiqui.co	professional	5dbafdc1-58cb-4902-80a1-955b8c4a1409	{"plan": "professional", "address": {"country": "IN"}, "lastName": "provident nemo  Harum fugit aliquid", "maxUsers": 10, "metadata": {"industry": "other", "companySize": "51-200", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Sed", "subdomain": "laborumillumaliasanimiquiqui", "adminEmail": "sedprovidentnemo.harumfugitaliquid@laborumillumaliasanimiquiqui.co", "companyName": "Blaine Goodwin"}	\N	50	\N	{}	\N	\N	dc1fd47e-137f-489b-832b-149c653dc7bc		\N	{"step": "provisioning"}	AggregateError [ECONNREFUSED]: \n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async PgDialect.migrate (file:///app/node_modules/drizzle-orm/pg-core/dialect.js:54:5)\n    at async migrate (file:///app/node_modules/drizzle-orm/node-postgres/migrator.js:4:3)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:52:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	a2818791e2de-18	\N	2026-02-18 15:48:27.535+00	2026-02-18 15:48:27.552+00	\N	\N	\N	\N	{}	2026-02-18 15:48:23.826434+00	2026-02-18 15:48:23.826434+00
8355cd6a-8773-4813-9918-f18316da4673	\N	completed	amylevy.oru.erp	agency_amylevy_db	Shelley Nicholson	eteuevenietadipi.distinctioaccusant@amylevy.app	professional	a1981e17-e9aa-4408-9336-8c1a091b683a	{"plan": "professional", "address": {"country": "IN"}, "lastName": "eu eveniet adipi Distinctio Accusant", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Et", "subdomain": "amylevy", "adminEmail": "eteuevenietadipi.distinctioaccusant@amylevy.app", "companyName": "Shelley Nicholson", "maxStorageGB": 10}	\N	100	\N	{}	\N	{"agency": {"id": "b654008a-8267-4dc0-80b4-cd12bba83e60", "name": "Shelley Nicholson", "taxId": null, "domain": "amylevy.oru.erp", "status": "active", "address": null, "features": [], "isActive": true, "maxUsers": 50, "metadata": {}, "settings": {}, "createdAt": "2026-02-18T17:21:37.927Z", "deletedAt": null, "updatedAt": "2026-02-18T17:21:40.485Z", "ownerUserId": "a1981e17-e9aa-4408-9336-8c1a091b683a", "trialEndsAt": null, "billingEmail": null, "contactEmail": "eteuevenietadipi.distinctioaccusant@amylevy.app", "contactPhone": null, "databaseName": "agency_amylevy_db", "maxStorageGB": 10, "subscriptionPlan": "professional", "subscriptionEndsAt": null, "subscriptionStartsAt": null}, "dbName": "agency_amylevy_db", "success": true}	b654008a-8267-4dc0-80b4-cd12bba83e60	\N	\N	\N	\N	0	3	\N	5	300	f6683f567e7a-18	\N	2026-02-18 17:21:37.985+00	2026-02-18 17:21:40.501+00	\N	\N	\N	\N	{}	2026-02-18 17:21:37.936784+00	2026-02-18 17:21:37.936784+00
4c56e17a-837c-44f4-9d74-6ea1ddf3ef73	\N	completed	evo.oru.erp	agency_evo_db	evo	main.admin@evo.com	professional	1d15d6d0-0e40-4556-b92d-fe0164ed4aaf	{"plan": "professional", "address": {"country": "IN"}, "lastName": "admin", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "main", "subdomain": "evo", "adminEmail": "main.admin@evo.com", "companyName": "evo", "maxStorageGB": 10}	\N	100	\N	{}	\N	{"agency": {"id": "78353732-c3e4-4f1c-81a5-c24b52fb7b56", "name": "evo", "taxId": null, "domain": "evo.oru.erp", "status": "active", "address": null, "features": [], "isActive": true, "maxUsers": 50, "metadata": {}, "settings": {}, "createdAt": "2026-02-19T02:47:18.844Z", "deletedAt": null, "updatedAt": "2026-02-19T02:47:21.941Z", "ownerUserId": "1d15d6d0-0e40-4556-b92d-fe0164ed4aaf", "trialEndsAt": null, "billingEmail": null, "contactEmail": "main.admin@evo.com", "contactPhone": null, "databaseName": "agency_evo_db", "maxStorageGB": 10, "subscriptionPlan": "professional", "subscriptionEndsAt": null, "subscriptionStartsAt": null}, "dbName": "agency_evo_db", "success": true}	78353732-c3e4-4f1c-81a5-c24b52fb7b56	\N	\N	\N	\N	0	3	\N	5	300	b2f53c33b714-18	\N	2026-02-19 02:47:18.907+00	2026-02-19 02:47:21.95+00	\N	\N	\N	\N	{}	2026-02-19 02:47:18.852755+00	2026-02-19 02:47:18.852755+00
f6d8d878-a5fe-4d42-8ce2-b0253239bce9	\N	failed	mouse.oru.erp	agency_mouse_db	mouse	mou.se@mouse.com	professional	47ca540b-9e2f-441e-86c6-41ea8e9f0b74	{"plan": "professional", "address": {"country": "IN"}, "lastName": "se", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "mou", "subdomain": "mouse", "adminEmail": "mou.se@mouse.com", "companyName": "mouse", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	f0ef09a0-813e-41d8-8cab-543a0e180610	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 03:22:35.905+00	2026-02-19 03:22:35.951+00	\N	\N	\N	\N	{}	2026-02-19 03:22:29.579809+00	2026-02-19 03:22:29.579809+00
89238f0e-01c2-4288-88d9-d01b3ccd9df3	\N	failed	mouse.oru.erp	agency_mouse_db	mouse	mou.se@mouse.com	professional	47ca540b-9e2f-441e-86c6-41ea8e9f0b74	{"plan": "professional", "address": {"country": "IN"}, "lastName": "se", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "mou", "subdomain": "mouse", "adminEmail": "mou.se@mouse.com", "companyName": "mouse", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	f0ef09a0-813e-41d8-8cab-543a0e180610	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 03:12:41.906+00	2026-02-19 03:12:41.944+00	\N	\N	\N	\N	{}	2026-02-19 03:12:36.805813+00	2026-02-19 03:12:36.805813+00
412ef94d-5c21-4305-b281-e51866151349	\N	failed	ashtonduke.oru.erp	agency_ashtonduke_db	Kaye Witt	nisiveritatisquia.consequuntursitvel@ashtonduke.io	professional	322c3b0c-d151-4d0a-8f1c-99f6192ae39b	{"plan": "professional", "address": {"country": "IN"}, "lastName": "veritatis quia  Consequuntur sit vel", "maxUsers": 10, "metadata": {"industry": "finance", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Nisi", "subdomain": "ashtonduke", "adminEmail": "nisiveritatisquia.consequuntursitvel@ashtonduke.io", "companyName": "Kaye Witt", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	47531588-5211-461e-a5f5-858eba491f87	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 04:37:52.696+00	2026-02-19 04:37:52.758+00	\N	\N	\N	\N	{}	2026-02-19 04:37:46.106938+00	2026-02-19 04:37:46.106938+00
d6a22070-2026-44b3-8b62-93c4db51ca8e	\N	failed	quisdignissimosnonitaqueducimusperspiciatiscorrupti.oru.erp	agency_quisdignissimosnonitaqueducimusperspiciatiscorrupti_db	Wendy Waller	aperiammollitiaut.autemeaconsequat@quisdignissimosnonitaqueducimusperspiciatiscorrupti.com	professional	c64e501c-2202-443b-908e-88c7132b75c8	{"plan": "professional", "address": {"country": "IN"}, "lastName": "mollitia ut  Autem ea consequat", "maxUsers": 10, "metadata": {"industry": "education", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Aperiam", "subdomain": "quisdignissimosnonitaqueducimusperspiciatiscorrupti", "adminEmail": "aperiammollitiaut.autemeaconsequat@quisdignissimosnonitaqueducimusperspiciatiscorrupti.com", "companyName": "Wendy Waller", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	2050121e-65f8-445e-8fd2-b888908999c2		\N	{"step": "provisioning"}	AggregateError [ECONNREFUSED]: \n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async PgDialect.migrate (file:///app/node_modules/drizzle-orm/pg-core/dialect.js:54:5)\n    at async migrate (file:///app/node_modules/drizzle-orm/node-postgres/migrator.js:4:3)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:56:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	2663cda2cd83-18	\N	2026-02-18 16:23:37.581+00	2026-02-18 16:23:37.597+00	\N	\N	\N	\N	{}	2026-02-18 16:23:33.881179+00	2026-02-18 16:23:33.881179+00
e208886e-3871-45c2-88e0-8b718c181af5	\N	failed	jenniferlevy.oru.erp	agency_jenniferlevy_db	Joelle Ferrell	uteaenimnullacup.temporsitinlorem@jenniferlevy.app	professional	dbcdae49-502d-4877-9a2d-02114259dc63	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ea enim nulla cup Tempor sit in lorem", "maxUsers": 10, "metadata": {"industry": "marketing", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Ut", "subdomain": "jenniferlevy", "adminEmail": "uteaenimnullacup.temporsitinlorem@jenniferlevy.app", "companyName": "Joelle Ferrell", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	8eb76b16-f6fa-4a8f-aa08-87fe319b30a3	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 03:36:44.007+00	2026-02-19 03:36:44.061+00	\N	\N	\N	\N	{}	2026-02-19 03:36:40.816349+00	2026-02-19 03:36:40.816349+00
4e8cf6b2-165f-40e5-8baa-0d9d80f203f8	\N	failed	jenniferlevy.oru.erp	agency_jenniferlevy_db	Joelle Ferrell	uteaenimnullacup.temporsitinlorem@jenniferlevy.app	professional	dbcdae49-502d-4877-9a2d-02114259dc63	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ea enim nulla cup Tempor sit in lorem", "maxUsers": 10, "metadata": {"industry": "marketing", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Ut", "subdomain": "jenniferlevy", "adminEmail": "uteaenimnullacup.temporsitinlorem@jenniferlevy.app", "companyName": "Joelle Ferrell", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	8eb76b16-f6fa-4a8f-aa08-87fe319b30a3	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 03:37:14.97+00	2026-02-19 03:37:15.02+00	\N	\N	\N	\N	{}	2026-02-19 03:37:11.74243+00	2026-02-19 03:37:11.74243+00
716f6e97-482a-4827-956b-9b6bc7ae61a5	\N	failed	jenniferlevy.oru.erp	agency_jenniferlevy_db	Joelle Ferrell	uteaenimnullacup.temporsitinlorem@jenniferlevy.app	professional	dbcdae49-502d-4877-9a2d-02114259dc63	{"plan": "professional", "address": {"country": "IN"}, "lastName": "ea enim nulla cup Tempor sit in lorem", "maxUsers": 10, "metadata": {"industry": "marketing", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Ut", "subdomain": "jenniferlevy", "adminEmail": "uteaenimnullacup.temporsitinlorem@jenniferlevy.app", "companyName": "Joelle Ferrell", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	8eb76b16-f6fa-4a8f-aa08-87fe319b30a3	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 03:36:48.542+00	2026-02-19 03:36:48.583+00	\N	\N	\N	\N	{}	2026-02-19 03:36:45.336833+00	2026-02-19 03:36:45.336833+00
0faeb86c-139f-421c-835b-526b02a0301a	\N	failed	vernondoyle.oru.erp	agency_vernondoyle_db	Wynne Hamilton	molestiaenisieums.voluptatumremiste@vernondoyle.com	professional	712ce548-5fed-4d35-87b4-6f6ef540ec3e	{"plan": "professional", "address": {"country": "AU"}, "lastName": "nisi eum s Voluptatum rem iste", "maxUsers": 10, "metadata": {"industry": "technology", "companySize": "201+", "primaryFocus": ""}, "password": "***", "settings": {"timezone": "Asia/Kolkata", "enableGST": true}, "firstName": "Molestiae", "subdomain": "vernondoyle", "adminEmail": "molestiaenisieums.voluptatumremiste@vernondoyle.com", "companyName": "Wynne Hamilton", "maxStorageGB": 10}	\N	50	\N	{}	\N	\N	8474c1b2-37db-493a-b6dd-ff294fcfd7de	relation "agency_settings" does not exist	\N	{"step": "provisioning"}	error: relation "agency_settings" does not exist\n    at /app/node_modules/pg-pool/index.js:45:11\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async Worker.processAgencyProvisioning [as processFn] (file:///app/dist/jobs/processors/agency-provisioning.job.js:86:9)\n    at async /app/node_modules/bullmq/dist/cjs/classes/worker.js:570:32	0	3	\N	5	300	d874e39c0745-18	\N	2026-02-19 14:26:49.971+00	2026-02-19 14:26:50.014+00	\N	\N	\N	\N	{}	2026-02-19 14:26:43.355534+00	2026-02-19 14:26:43.355534+00
\.


--
-- Data for Name: agency_provisioning_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agency_provisioning_logs (id, job_id, level, message, step, details, created_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, agency_id, user_id, session_id, table_name, record_id, action, old_values, new_values, changed_fields, ip_address, user_agent, request_id, endpoint, method, status_code, error_message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.currencies (id, code, name, symbol, exchange_rate, is_base, is_active, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_verification_tokens (id, user_id, token_hash, email, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, agency_id, title, message, type, priority, link, is_read, read_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: page_catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page_catalog (id, path, title, description, icon, category, parent_page_id, display_order, base_cost, billing_cycle, min_subscription_tier, required_features, dependent_pages, is_active, is_beta, requires_approval, requires_onboarding, has_trial, trial_duration_days, permissions_required, api_quota_default, storage_quota_mb, max_concurrent_users, seo_title, seo_description, seo_keywords, documentation_url, video_tutorial_url, support_email, release_date, deprecation_date, replacement_page_id, tags, metadata, analytics_enabled, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: page_pricing_tiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page_pricing_tiers (id, page_id, tier_name, tier_level, cost, billing_cycle, quota_overrides, feature_flags, is_active, valid_from, valid_until, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: page_recommendation_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page_recommendation_rules (id, page_id, industry, company_size, primary_focus, business_goals, priority, weight, is_required, min_employees, max_employees, min_revenue, max_revenue, geographic_regions, exclude_industries, custom_criteria, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: page_usage_analytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.page_usage_analytics (id, agency_id, page_id, user_id, date, view_count, unique_users, total_duration_seconds, avg_session_duration_seconds, action_count, error_count, performance_score, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profiles (id, user_id, agency_id, full_name, display_name, phone, phone_extension, department, "position", employee_code, hire_date, avatar_url, personal_email, personal_email_verified, personal_email_verified_at, timezone, language, date_format, time_format, notification_preferences, theme_preferences, is_active, bio, social_links, metadata, deleted_at, created_at, updated_at) FROM stdin;
f421d209-cda5-4831-81f0-47a3e9c8ca50	91966e17-ca5d-485f-961c-d1537c2009e7	\N	System Admin	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	UTC	en	YYYY-MM-DD	24h	{}	{}	t	\N	\N	{}	\N	2026-02-18 13:04:47.468766+00	2026-02-18 13:04:47.468766+00
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_plans (id, name, slug, description, base_price_monthly, base_price_yearly, max_users, max_storage_gb, features, is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_alert_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_alert_rules (id, rule_name, metric_name, condition, threshold_value, comparison_operator, severity, duration_seconds, cooldown_seconds, notification_channels, is_enabled, description, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_alerts (id, alert_rule_id, severity, title, message, metric_name, current_value, threshold_value, status, triggered_at, acknowledged_at, acknowledged_by, resolved_at, resolved_by, resolution_notes, notification_sent, notification_sent_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: system_features; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_features (id, name, description, feature_key, is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_health_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_health_metrics (id, "timestamp", overall_status, db_status, db_response_time_ms, db_size_bytes, db_connections_active, db_connections_idle, db_connections_waiting, db_connections_max, db_connections_usage_percent, db_locks_count, db_deadlocks_count, db_cache_hit_ratio, db_index_usage_percent, db_table_count, db_total_rows, db_temp_files, db_temp_bytes, db_transaction_rate, db_query_rate, db_slow_queries, redis_status, redis_response_time_ms, redis_memory_used_bytes, redis_memory_peak_bytes, redis_memory_fragmentation_ratio, redis_connected_clients, redis_blocked_clients, redis_commands_processed, redis_keyspace_hits, redis_keyspace_misses, redis_hit_rate, redis_evicted_keys, redis_expired_keys, redis_cpu_usage_percent, system_platform, system_arch, system_node_version, system_uptime_seconds, system_memory_total_bytes, system_memory_used_bytes, system_memory_free_bytes, system_memory_usage_percent, system_cpu_count, system_cpu_model, system_cpu_usage_percent, system_load_avg_1min, system_load_avg_5min, system_load_avg_15min, system_disk_total_bytes, system_disk_used_bytes, system_disk_free_bytes, system_disk_usage_percent, process_memory_rss_bytes, process_memory_heap_total_bytes, process_memory_heap_used_bytes, process_memory_heap_limit_bytes, process_memory_external_bytes, process_cpu_user_microseconds, process_cpu_system_microseconds, process_event_loop_lag_ms, api_response_time_avg_ms, api_response_time_p50_ms, api_response_time_p95_ms, api_response_time_p99_ms, api_requests_total, api_requests_per_second, api_error_count, api_error_rate_percent, api_timeout_count, active_sessions, active_websockets, queue_length, queue_processing_rate, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: system_incidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_incidents (id, incident_number, title, description, severity, status, affected_services, started_at, detected_at, acknowledged_at, resolved_at, duration_seconds, root_cause, resolution_summary, impact_description, affected_users_count, created_by, assigned_to, related_alerts, timeline, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, system_name, system_tagline, system_description, logo_url, logo_light_url, logo_dark_url, favicon_url, login_logo_url, email_logo_url, meta_title, meta_description, meta_keywords, og_image_url, og_title, og_description, twitter_card_type, twitter_site, twitter_creator, google_analytics_id, google_tag_manager_id, facebook_pixel_id, custom_tracking_code, custom_head_scripts, custom_body_scripts, ad_network_enabled, ad_network_code, ad_placement_config, support_email, support_phone, support_address, social_links, legal_links, email_provider, smtp_host, smtp_port, smtp_user, smtp_password_encrypted, smtp_from_email, smtp_from_name, smtp_use_tls, smtp_use_ssl, sendgrid_api_key_encrypted, sendgrid_from_email, sendgrid_from_name, mailgun_api_key_encrypted, mailgun_domain, mailgun_region, aws_ses_region, aws_ses_access_key_encrypted, aws_ses_secret_key_encrypted, aws_ses_from_email, aws_ses_from_name, resend_api_key_encrypted, resend_from_email, resend_from_name, postmark_api_key_encrypted, postmark_from_email, postmark_from_name, email_test_mode, email_test_recipient, password_min_length, password_max_length, password_require_uppercase, password_require_lowercase, password_require_numbers, password_require_symbols, password_expiry_days, password_history_count, session_timeout_minutes, session_absolute_timeout_hours, max_concurrent_sessions, max_login_attempts, lockout_duration_minutes, progressive_lockout, require_email_verification, email_verification_expires_hours, enable_two_factor, force_two_factor_for_roles, enable_captcha, captcha_provider, captcha_site_key, captcha_secret_key_encrypted, captcha_threshold, enable_rate_limiting, rate_limit_requests_per_minute, rate_limit_burst_size, ip_whitelist, ip_blacklist, enable_ip_geolocation, blocked_countries, allowed_countries, file_storage_provider, file_storage_path, max_file_size_bytes, max_total_storage_bytes, allowed_mime_types, blocked_mime_types, enable_virus_scanning, virus_scan_provider, aws_s3_bucket, aws_s3_region, aws_s3_access_key_encrypted, aws_s3_secret_key_encrypted, aws_s3_public_url, cdn_enabled, cdn_url, api_enabled, api_rate_limit_enabled, api_rate_limit_requests_per_minute, api_timeout_seconds, api_max_payload_size_bytes, enable_api_documentation, api_documentation_url, enable_cors, cors_allowed_origins, cors_allowed_methods, cors_allowed_headers, cors_max_age_seconds, log_level, enable_audit_logging, log_retention_days, log_sensitive_data, enable_error_tracking, sentry_dsn_encrypted, sentry_environment, sentry_sample_rate, enable_performance_monitoring, performance_sample_rate, enable_auto_backup, backup_schedule, backup_retention_days, backup_storage_provider, backup_storage_path, backup_encryption_enabled, backup_compression_enabled, maintenance_mode, maintenance_message, maintenance_allowed_ips, maintenance_start_time, maintenance_end_time, default_language, available_languages, default_timezone, default_currency_code, default_date_format, default_time_format, enable_registration, registration_requires_approval, registration_auto_verify_email, default_user_role, enable_invitations, invitation_expiry_hours, terms_version, terms_last_updated, privacy_version, privacy_last_updated, cookie_consent_enabled, gdpr_compliant, data_retention_days, enable_data_export, enable_account_deletion, system_version, deployment_environment, feature_flags, custom_settings, metadata, created_at, updated_at, created_by, updated_by) FROM stdin;
56571525-0937-4866-ab30-98624dc7f275	BuildFlow ERP	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	summary_large_image	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	{}	\N	\N	\N	{}	{}	smtp	\N	587	\N	\N	\N	\N	t	f	\N	\N	\N	\N	\N	us	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	8	128	t	t	t	f	\N	5	60	24	5	5	30	t	t	24	f	{}	f	recaptcha_v3	\N	\N	0.50	t	60	100	\N	\N	f	\N	\N	local	/app/storage	10485760	\N	{image/jpeg,image/png,image/gif,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/zip}	{application/x-executable,application/x-msdos-program}	f	\N	\N	\N	\N	\N	\N	f	\N	t	t	100	30	1048576	t	\N	t	\N	{GET,POST,PUT,DELETE,PATCH}	{Content-Type,Authorization}	86400	info	t	90	f	f	\N	\N	1.00	f	0.10	t	0 2 * * *	30	local	/app/backups	t	t	f	\N	\N	\N	\N	en	{en}	UTC	USD	YYYY-MM-DD	HH:mm:ss	t	f	f	\N	t	72	\N	\N	\N	\N	t	t	\N	t	t	\N	production	{}	{}	{}	2026-02-18 05:08:30.669416+00	2026-02-18 05:08:30.669416+00	\N	\N
\.


--
-- Data for Name: system_sla_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_sla_metrics (id, metric_date, service_name, uptime_percentage, downtime_minutes, total_requests, successful_requests, failed_requests, avg_response_time_ms, p95_response_time_ms, p99_response_time_ms, incident_count, mttr_minutes, mttd_minutes, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tickets (id, ticket_number, title, description, status, priority, category, agency_id, user_id, assigned_to, department, page_url, screenshot_url, console_logs, error_details, browser_info, metadata, created_at, updated_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (id, user_id, agency_id, role, custom_role_name, permissions, is_active, valid_from, valid_until, assigned_by, assigned_at, revoked_at, revoked_by, metadata) FROM stdin;
9bf7dfb4-e459-478b-80b7-2d0225c27b41	eb06b795-c264-4686-bc7d-fe65126d2dca	\N	super_admin	\N	[]	t	2026-02-18 12:59:23.165294+00	\N	\N	2026-02-18 12:59:23.165294+00	\N	\N	{}
81e2e8ff-545f-424f-b96c-c9cd66e1a3ba	91966e17-ca5d-485f-961c-d1537c2009e7	\N	super_admin	\N	[]	t	2026-02-18 13:04:47.473568+00	\N	\N	2026-02-18 13:04:47.473568+00	\N	\N	{}
27b5ef4b-5fca-4212-9dc7-7485f42b30d3	fa25e6e1-5bb2-4363-8958-b610dcb3ccff	\N	agency_admin	\N	[]	t	2026-02-19 02:07:46.653597+00	\N	\N	2026-02-19 02:07:46.653597+00	\N	\N	{}
d0aab28c-658b-498d-89cc-4359dd59241a	abf06f11-bf9d-41d3-a986-9950e361e6da	\N	agency_admin	\N	[]	t	2026-02-19 02:23:01.446158+00	\N	\N	2026-02-19 02:23:01.446158+00	\N	\N	{}
94589637-2a5d-453d-9d88-64c63f2e0e10	1d15d6d0-0e40-4556-b92d-fe0164ed4aaf	\N	agency_admin	\N	[]	t	2026-02-19 02:47:18.83539+00	\N	\N	2026-02-19 02:47:18.83539+00	\N	\N	{}
df0b0285-a171-4509-a4c3-feb33d98560e	47ca540b-9e2f-441e-86c6-41ea8e9f0b74	\N	agency_admin	\N	[]	t	2026-02-19 03:12:36.785639+00	\N	\N	2026-02-19 03:12:36.785639+00	\N	\N	{}
54bf2a36-2b16-4eb1-83c9-b9cff9a855b4	47ca540b-9e2f-441e-86c6-41ea8e9f0b74	\N	agency_admin	\N	[]	t	2026-02-19 03:16:50.800459+00	\N	\N	2026-02-19 03:16:50.800459+00	\N	\N	{}
c6f3dea2-7083-4b64-9928-3ce404aae89f	47ca540b-9e2f-441e-86c6-41ea8e9f0b74	\N	agency_admin	\N	[]	t	2026-02-19 03:22:29.571701+00	\N	\N	2026-02-19 03:22:29.571701+00	\N	\N	{}
8a52a01c-9223-49ef-a018-0eb4624d5efa	dbcdae49-502d-4877-9a2d-02114259dc63	\N	agency_admin	\N	[]	t	2026-02-19 03:36:40.797578+00	\N	\N	2026-02-19 03:36:40.797578+00	\N	\N	{}
e60d2953-b2bb-4d1e-9853-6fe8bff83412	dbcdae49-502d-4877-9a2d-02114259dc63	\N	agency_admin	\N	[]	t	2026-02-19 03:36:45.332722+00	\N	\N	2026-02-19 03:36:45.332722+00	\N	\N	{}
3fb506ff-cb0b-4e19-92db-d34ef8b5515c	dbcdae49-502d-4877-9a2d-02114259dc63	\N	agency_admin	\N	[]	t	2026-02-19 03:37:11.735299+00	\N	\N	2026-02-19 03:37:11.735299+00	\N	\N	{}
df812778-7c28-4eb8-a399-ceca61a75c38	dbcdae49-502d-4877-9a2d-02114259dc63	\N	agency_admin	\N	[]	t	2026-02-19 03:37:33.950016+00	\N	\N	2026-02-19 03:37:33.950016+00	\N	\N	{}
206b80fe-88ff-4360-9212-7526eca4affb	dbcdae49-502d-4877-9a2d-02114259dc63	\N	agency_admin	\N	[]	t	2026-02-19 03:41:21.105022+00	\N	\N	2026-02-19 03:41:21.105022+00	\N	\N	{}
a343fa1f-cae8-4578-a477-2961b5c52b74	7ab7da08-1947-4ab4-9c41-0fcaf5190d09	\N	agency_admin	\N	[]	t	2026-02-19 03:41:43.934677+00	\N	\N	2026-02-19 03:41:43.934677+00	\N	\N	{}
917d967c-03b0-42cd-a514-1e8bbf5a9fa3	322c3b0c-d151-4d0a-8f1c-99f6192ae39b	\N	agency_admin	\N	[]	t	2026-02-19 04:37:46.0895+00	\N	\N	2026-02-19 04:37:46.0895+00	\N	\N	{}
83d0c577-2a3c-4e76-a89b-c02e48f1b84d	712ce548-5fed-4d35-87b4-6f6ef540ec3e	\N	agency_admin	\N	[]	t	2026-02-19 14:26:43.337385+00	\N	\N	2026-02-19 14:26:43.337385+00	\N	\N	{}
c2788521-e181-4388-9601-ea7169d6638f	712ce548-5fed-4d35-87b4-6f6ef540ec3e	\N	agency_admin	\N	[]	t	2026-02-19 14:43:22.847048+00	\N	\N	2026-02-19 14:43:22.847048+00	\N	\N	{}
9cd0750f-1cf7-4840-b2c3-66792479311f	29ddab1d-002b-4022-9f87-6816293a5f8e	\N	agency_admin	\N	[]	t	2026-02-20 01:45:37.918984+00	\N	\N	2026-02-20 01:45:37.918984+00	\N	\N	{}
bdb93d2e-df36-4298-8c65-a9c07fae30c4	e013de97-fcb4-4423-9b24-7070b8ef9b1f	\N	agency_admin	\N	[]	t	2026-02-20 02:07:42.472895+00	\N	\N	2026-02-20 02:07:42.472895+00	\N	\N	{}
ff782116-f6a8-4adb-90b4-672a11af3f07	30ead45c-2658-42f4-9406-3f3f27d0b545	\N	agency_admin	\N	[]	t	2026-02-20 02:08:36.424637+00	\N	\N	2026-02-20 02:08:36.424637+00	\N	\N	{}
ec7bdcae-0971-4d85-b497-5915c13e20e6	712ce548-5fed-4d35-87b4-6f6ef540ec3e	\N	agency_admin	\N	[]	t	2026-02-20 02:15:40.310816+00	\N	\N	2026-02-20 02:15:40.310816+00	\N	\N	{}
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, token_hash, refresh_token_hash, ip_address, user_agent, device_fingerprint, expires_at, refresh_expires_at, last_activity_at, is_active, revoked_at, revoked_reason, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, email_normalized, password_hash, email_confirmed, email_confirmed_at, phone, phone_verified, phone_verified_at, status, failed_login_attempts, locked_until, password_changed_at, must_change_password, terms_accepted_at, terms_version, privacy_accepted_at, last_sign_in_at, last_sign_in_ip, sign_in_count, raw_user_meta_data, deleted_at, created_at, updated_at) FROM stdin;
b694851e-24a2-4e91-a0a4-8d2a0d12d200	ipsummaioreslabor.nesciuntsintaliqu@quominimeumidculpaeaomnisaspernaturametvelelitvol.dev	ipsummaioreslabor.nesciuntsintaliqu@quominimeumidculpaeaomnisaspernaturametvelelitvol.dev	$2a$12$8Tc2LJpN2FJoLUP79y2RLO8J8CUzvDFDT7QkICakA39tWde6LVMUq	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 12:53:25.301+00	\N	0	{}	\N	2026-02-18 12:53:23.775143+00	2026-02-18 12:53:23.775143+00
1d15d6d0-0e40-4556-b92d-fe0164ed4aaf	main.admin@evo.com	main.admin@evo.com	$2a$12$WpsfxyC9XlG9qUtQME8ryOgyk5vokmrUUIZEFZqGPiOczwf0P7YCi	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-19 02:47:24.548+00	\N	0	{}	\N	2026-02-19 02:47:18.829215+00	2026-02-19 02:47:18.829215+00
47ca540b-9e2f-441e-86c6-41ea8e9f0b74	mou.se@mouse.com	mou.se@mouse.com	$2a$12$Lu.hgUBKA6ns9Ks0EN4KuuGmact6Tbf8GnPhc56ZRftWy4TDu0tVi	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	\N	\N	0	{}	\N	2026-02-19 03:12:36.776475+00	2026-02-19 03:12:36.776475+00
83c942d9-4841-4743-8953-c092d2890773	utipsumnostrumli.ipsumdolorequodod@sitinprovidentvoluptateaperiamoditexconsequaturaut.agency	utipsumnostrumli.ipsumdolorequodod@sitinprovidentvoluptateaperiamoditexconsequaturaut.agency	$2a$12$lwnwoGRK7VzgxqqAwUUoSeYrJrxqolyMjnPSqS7VGfwIbIMAbxvTm	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 15:05:39.813+00	\N	0	{}	\N	2026-02-18 15:05:38.136597+00	2026-02-18 15:05:38.136597+00
5dbafdc1-58cb-4902-80a1-955b8c4a1409	sedprovidentnemo.harumfugitaliquid@laborumillumaliasanimiquiqui.co	sedprovidentnemo.harumfugitaliquid@laborumillumaliasanimiquiqui.co	$2a$12$FXv6wlMp9gWMEMdC5YYZmO91NXO0ekoqWgX1kEFPMae11S9gtXrSu	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 15:48:25.398+00	\N	0	{}	\N	2026-02-18 15:48:23.8126+00	2026-02-18 15:48:23.8126+00
c64e501c-2202-443b-908e-88c7132b75c8	aperiammollitiaut.autemeaconsequat@quisdignissimosnonitaqueducimusperspiciatiscorrupti.com	aperiammollitiaut.autemeaconsequat@quisdignissimosnonitaqueducimusperspiciatiscorrupti.com	$2a$12$loU49HlNverCvBZqz3Wb3OLcyagPFMaMhDKsZge1An6aDuo5m2jaW	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 16:23:35.482+00	\N	0	{}	\N	2026-02-18 16:23:33.858708+00	2026-02-18 16:23:33.858708+00
eb06b795-c264-4686-bc7d-fe65126d2dca	burhan.ali@easyio.com	burhan.ali@easyio.com	$2a$12$vjPQN0F9VAbK8ntuKPa7seYq81Nx.KHn92rHs8RdF/7KjOSh1s.bW	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 16:23:58.318+00	\N	0	{}	\N	2026-02-18 12:54:07.535531+00	2026-02-18 12:54:07.535531+00
91966e17-ca5d-485f-961c-d1537c2009e7	admin@oru.com	admin@oru.com	$2a$12$mJNI2oFHWZYpxVMp9KQlROAYgmto0pes/hxixDiOAc96dUMDMJgN.	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 16:25:15.839+00	\N	0	{}	\N	2026-02-18 13:04:47.453644+00	2026-02-18 13:04:47.453644+00
31fe0044-e19c-49a3-acb1-383cfcb228de	ipsumatqueexceptur.commodolaborumlab@voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu.tech	ipsumatqueexceptur.commodolaborumlab@voluptatemeiusmodadduissequiiureobcaecatiutetaspernatu.tech	$2a$12$Y6JgZK/V.Qw3W4DvNKsgwuo2Qv2Di/VRhl1xrVfFMC8WaHZzNGZF.	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 16:42:47.676+00	\N	0	{}	\N	2026-02-18 16:42:46.133277+00	2026-02-18 16:42:46.133277+00
dbcdae49-502d-4877-9a2d-02114259dc63	uteaenimnullacup.temporsitinlorem@jenniferlevy.app	uteaenimnullacup.temporsitinlorem@jenniferlevy.app	$2a$12$/g7hE6Pn7Q82mB8n.TGAHufMZfCDFUcev6vtGIQ./hmq.dfUKNSma	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	\N	\N	0	{}	\N	2026-02-19 03:36:40.793094+00	2026-02-19 03:36:40.793094+00
d2f437f9-a012-4d93-845d-31b537dedd0b	burhan.ali@gmail.com	burhan.ali@gmail.com	$2a$12$pwtLxdxsw7h1GRjREUC61OYi1TjZ0qlJWs5Jp9DMf2lVXnsh4ECfG	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 16:51:04.07+00	\N	0	{}	\N	2026-02-18 16:50:33.807833+00	2026-02-18 16:50:33.807833+00
19189810-fe9e-4ac2-b440-5ccb1427a08b	aliquiplaborissunt.blanditiisetsitdo@aubreybaxter.net	aliquiplaborissunt.blanditiisetsitdo@aubreybaxter.net	$2a$12$74upma2q44AYPMJ0o0BoO.J.m6n5oTE8OQbm2kfPZvXx48NYRqj3q	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 17:09:17.532+00	\N	0	{}	\N	2026-02-18 17:09:13.986666+00	2026-02-18 17:09:13.986666+00
a1981e17-e9aa-4408-9336-8c1a091b683a	eteuevenietadipi.distinctioaccusant@amylevy.app	eteuevenietadipi.distinctioaccusant@amylevy.app	$2a$12$vL1SZB3oyrWxOJxZ/TWAOeC7I3lh4GlFFPVrs8Icb2xgMmE.n5Hl6	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-18 17:21:42.215+00	\N	0	{}	\N	2026-02-18 17:21:37.921477+00	2026-02-18 17:21:37.921477+00
fa25e6e1-5bb2-4363-8958-b610dcb3ccff	burhan.ali@mob.app	burhan.ali@mob.app	$2a$12$duPlS7aCz9xGA.whzVyW3OKf662qXSCBzschZr0dco4MxcDemw8qC	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-19 02:07:52.406+00	\N	0	{}	\N	2026-02-19 02:07:46.646903+00	2026-02-19 02:07:46.646903+00
abf06f11-bf9d-41d3-a986-9950e361e6da	burhan.ali@facebook.com	burhan.ali@facebook.com	$2a$12$W9vdEVmhqks5vDak9Ck.ju93oexxHRqY/ET5lhzWz7NdLQ4.PIfwO	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	2026-02-19 02:23:05.322+00	\N	0	{}	\N	2026-02-19 02:23:01.440538+00	2026-02-19 02:23:01.440538+00
7ab7da08-1947-4ab4-9c41-0fcaf5190d09	temporaexcepteurfu.exercitationconsequ@serenahahn.io	temporaexcepteurfu.exercitationconsequ@serenahahn.io	$2a$12$GWfVFFrQkK4sLu6IVsLVlev3wcfSNua5yXD.7C3FFJN2XSI0SwQIi	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	\N	\N	0	{}	\N	2026-02-19 03:41:43.930684+00	2026-02-19 03:41:43.930684+00
322c3b0c-d151-4d0a-8f1c-99f6192ae39b	nisiveritatisquia.consequuntursitvel@ashtonduke.io	nisiveritatisquia.consequuntursitvel@ashtonduke.io	$2a$12$UugfL10n5wMFXs/VwDaOpebQto4mifBtxsrJXwsYaeTdg3j8QTBBm	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	\N	\N	0	{}	\N	2026-02-19 04:37:46.083673+00	2026-02-19 04:37:46.083673+00
712ce548-5fed-4d35-87b4-6f6ef540ec3e	molestiaenisieums.voluptatumremiste@vernondoyle.com	molestiaenisieums.voluptatumremiste@vernondoyle.com	$2a$12$C69Atqi8ZgHnNWTF7o3XvumasUd7iXd2yh8UZnRoVdKbsH1Btu7LS	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	\N	\N	0	{}	\N	2026-02-19 14:26:43.329209+00	2026-02-19 14:26:43.329209+00
29ddab1d-002b-4022-9f87-6816293a5f8e	jyly@mailinator.com	jyly@mailinator.com	$2a$12$qk4TVC/TU5R6NEfs2Z1ba.DbzuWl/cUz39oVt7hjGd9tUOXc.jZEq	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	\N	\N	0	{}	\N	2026-02-20 01:45:37.912097+00	2026-02-20 01:45:37.912097+00
e013de97-fcb4-4423-9b24-7070b8ef9b1f	kezafor@mailinator.com	kezafor@mailinator.com	$2a$12$e9TqisFDnTh85AMNaQm.AukA4gqCuZwdyZhl2xmO62y3.eRr/h4te	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	\N	\N	0	{}	\N	2026-02-20 02:07:42.468633+00	2026-02-20 02:07:42.468633+00
30ead45c-2658-42f4-9406-3f3f27d0b545	97patrizia@virgilian.com	97patrizia@virgilian.com	$2a$12$JeKaojvkj.9iGonHvaN65.ZHB7sxediq/UAdA2WKSdSpyUW1vxm2G	t	\N	\N	f	\N	active	0	\N	\N	f	\N	\N	\N	\N	\N	0	{}	\N	2026-02-20 02:08:36.420665+00	2026-02-20 02:08:36.420665+00
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: postgres
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 1, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: agencies agencies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agencies
    ADD CONSTRAINT agencies_pkey PRIMARY KEY (id);


--
-- Name: agency_page_assignments agency_page_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_assignments
    ADD CONSTRAINT agency_page_assignments_pkey PRIMARY KEY (id);


--
-- Name: agency_page_requests agency_page_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_requests
    ADD CONSTRAINT agency_page_requests_pkey PRIMARY KEY (id);


--
-- Name: agency_provisioning_jobs agency_provisioning_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_provisioning_jobs
    ADD CONSTRAINT agency_provisioning_jobs_pkey PRIMARY KEY (id);


--
-- Name: agency_provisioning_logs agency_provisioning_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_provisioning_logs
    ADD CONSTRAINT agency_provisioning_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_code_unique UNIQUE (code);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: page_catalog page_catalog_path_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_catalog
    ADD CONSTRAINT page_catalog_path_unique UNIQUE (path);


--
-- Name: page_catalog page_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_catalog
    ADD CONSTRAINT page_catalog_pkey PRIMARY KEY (id);


--
-- Name: page_pricing_tiers page_pricing_tiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_pricing_tiers
    ADD CONSTRAINT page_pricing_tiers_pkey PRIMARY KEY (id);


--
-- Name: page_recommendation_rules page_recommendation_rules_page_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_recommendation_rules
    ADD CONSTRAINT page_recommendation_rules_page_id_unique UNIQUE (page_id);


--
-- Name: page_recommendation_rules page_recommendation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_recommendation_rules
    ADD CONSTRAINT page_recommendation_rules_pkey PRIMARY KEY (id);


--
-- Name: page_usage_analytics page_usage_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_usage_analytics
    ADD CONSTRAINT page_usage_analytics_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_name_unique UNIQUE (name);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_slug_unique UNIQUE (slug);


--
-- Name: system_alert_rules system_alert_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_alert_rules
    ADD CONSTRAINT system_alert_rules_pkey PRIMARY KEY (id);


--
-- Name: system_alert_rules system_alert_rules_rule_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_alert_rules
    ADD CONSTRAINT system_alert_rules_rule_name_unique UNIQUE (rule_name);


--
-- Name: system_alerts system_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_pkey PRIMARY KEY (id);


--
-- Name: system_features system_features_feature_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_features
    ADD CONSTRAINT system_features_feature_key_unique UNIQUE (feature_key);


--
-- Name: system_features system_features_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_features
    ADD CONSTRAINT system_features_pkey PRIMARY KEY (id);


--
-- Name: system_health_metrics system_health_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_health_metrics
    ADD CONSTRAINT system_health_metrics_pkey PRIMARY KEY (id);


--
-- Name: system_incidents system_incidents_incident_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_incidents
    ADD CONSTRAINT system_incidents_incident_number_unique UNIQUE (incident_number);


--
-- Name: system_incidents system_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_incidents
    ADD CONSTRAINT system_incidents_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_sla_metrics system_sla_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_sla_metrics
    ADD CONSTRAINT system_sla_metrics_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_agencies_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agencies_created_at ON public.agencies USING btree (created_at);


--
-- Name: idx_agencies_database_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_agencies_database_name ON public.agencies USING btree (database_name) WHERE (deleted_at IS NULL);


--
-- Name: idx_agencies_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_agencies_domain ON public.agencies USING btree (domain) WHERE (deleted_at IS NULL);


--
-- Name: idx_agencies_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agencies_is_active ON public.agencies USING btree (is_active) WHERE (deleted_at IS NULL);


--
-- Name: idx_agencies_owner_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agencies_owner_user_id ON public.agencies USING btree (owner_user_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_agencies_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agencies_status ON public.agencies USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: idx_agencies_subscription_plan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agencies_subscription_plan ON public.agencies USING btree (subscription_plan);


--
-- Name: idx_agency_page_assignments_agency_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_assignments_agency_id ON public.agency_page_assignments USING btree (agency_id);


--
-- Name: idx_agency_page_assignments_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_assignments_expires ON public.agency_page_assignments USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_agency_page_assignments_page_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_assignments_page_id ON public.agency_page_assignments USING btree (page_id);


--
-- Name: idx_agency_page_assignments_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_assignments_status ON public.agency_page_assignments USING btree (status);


--
-- Name: idx_agency_page_assignments_trial; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_assignments_trial ON public.agency_page_assignments USING btree (trial_ends_at) WHERE ((is_trial = true) AND (status = 'trial'::public.page_assignment_status));


--
-- Name: idx_agency_page_requests_agency_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_requests_agency_id ON public.agency_page_requests USING btree (agency_id);


--
-- Name: idx_agency_page_requests_page_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_requests_page_id ON public.agency_page_requests USING btree (page_id);


--
-- Name: idx_agency_page_requests_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_requests_priority ON public.agency_page_requests USING btree (priority, status);


--
-- Name: idx_agency_page_requests_requested_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_requests_requested_by ON public.agency_page_requests USING btree (requested_by);


--
-- Name: idx_agency_page_requests_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_page_requests_status ON public.agency_page_requests USING btree (status);


--
-- Name: idx_agency_provisioning_jobs_agency_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_provisioning_jobs_agency_id ON public.agency_provisioning_jobs USING btree (agency_id);


--
-- Name: idx_agency_provisioning_jobs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_provisioning_jobs_created_at ON public.agency_provisioning_jobs USING btree (created_at);


--
-- Name: idx_agency_provisioning_jobs_database_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_provisioning_jobs_database_name ON public.agency_provisioning_jobs USING btree (database_name);


--
-- Name: idx_agency_provisioning_jobs_domain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_provisioning_jobs_domain ON public.agency_provisioning_jobs USING btree (domain);


--
-- Name: idx_agency_provisioning_jobs_idempotency; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_agency_provisioning_jobs_idempotency ON public.agency_provisioning_jobs USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: idx_agency_provisioning_jobs_requested_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_provisioning_jobs_requested_by ON public.agency_provisioning_jobs USING btree (requested_by);


--
-- Name: idx_agency_provisioning_jobs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_provisioning_jobs_status ON public.agency_provisioning_jobs USING btree (status, priority);


--
-- Name: idx_agency_provisioning_logs_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_provisioning_logs_job_id ON public.agency_provisioning_logs USING btree (job_id, created_at);


--
-- Name: idx_agency_provisioning_logs_level; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agency_provisioning_logs_level ON public.agency_provisioning_logs USING btree (level) WHERE (level = ANY (ARRAY['error'::text, 'warn'::text]));


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_agency_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_agency_id ON public.audit_logs USING btree (agency_id) WHERE (agency_id IS NOT NULL);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_record_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_record_id ON public.audit_logs USING btree (record_id) WHERE (record_id IS NOT NULL);


--
-- Name: idx_audit_logs_request_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_request_id ON public.audit_logs USING btree (request_id) WHERE (request_id IS NOT NULL);


--
-- Name: idx_audit_logs_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_session_id ON public.audit_logs USING btree (session_id) WHERE (session_id IS NOT NULL);


--
-- Name: idx_audit_logs_table_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_table_name ON public.audit_logs USING btree (table_name);


--
-- Name: idx_audit_logs_table_record; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_table_record ON public.audit_logs USING btree (table_name, record_id);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: idx_currencies_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_currencies_code ON public.currencies USING btree (code);


--
-- Name: idx_currencies_is_base; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_currencies_is_base ON public.currencies USING btree (is_base);


--
-- Name: idx_email_verification_tokens_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_verification_tokens_expires_at ON public.email_verification_tokens USING btree (expires_at) WHERE (used_at IS NULL);


--
-- Name: idx_email_verification_tokens_token_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_email_verification_tokens_token_hash ON public.email_verification_tokens USING btree (token_hash) WHERE (used_at IS NULL);


--
-- Name: idx_email_verification_tokens_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_verification_tokens_user_id ON public.email_verification_tokens USING btree (user_id) WHERE (used_at IS NULL);


--
-- Name: idx_notifications_agency_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_agency_id ON public.notifications USING btree (agency_id);


--
-- Name: idx_notifications_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_created_at ON public.notifications USING btree (created_at);


--
-- Name: idx_notifications_is_read; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_is_read ON public.notifications USING btree (is_read);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_page_catalog_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_catalog_category ON public.page_catalog USING btree (category) WHERE ((is_active = true) AND (deleted_at IS NULL));


--
-- Name: idx_page_catalog_display_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_catalog_display_order ON public.page_catalog USING btree (category, display_order);


--
-- Name: idx_page_catalog_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_catalog_is_active ON public.page_catalog USING btree (is_active) WHERE (deleted_at IS NULL);


--
-- Name: idx_page_catalog_parent_page_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_catalog_parent_page_id ON public.page_catalog USING btree (parent_page_id) WHERE (parent_page_id IS NOT NULL);


--
-- Name: idx_page_catalog_path; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_page_catalog_path ON public.page_catalog USING btree (path) WHERE (deleted_at IS NULL);


--
-- Name: idx_page_pricing_tiers_page_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_pricing_tiers_page_id ON public.page_pricing_tiers USING btree (page_id) WHERE (is_active = true);


--
-- Name: idx_page_pricing_tiers_tier_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_pricing_tiers_tier_name ON public.page_pricing_tiers USING btree (tier_name);


--
-- Name: idx_page_recommendation_rules_page_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_recommendation_rules_page_id ON public.page_recommendation_rules USING btree (page_id) WHERE (is_active = true);


--
-- Name: idx_page_recommendation_rules_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_recommendation_rules_priority ON public.page_recommendation_rules USING btree (priority);


--
-- Name: idx_page_usage_analytics_agency_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_usage_analytics_agency_id ON public.page_usage_analytics USING btree (agency_id);


--
-- Name: idx_page_usage_analytics_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_usage_analytics_date ON public.page_usage_analytics USING btree (date);


--
-- Name: idx_page_usage_analytics_page_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_page_usage_analytics_page_id ON public.page_usage_analytics USING btree (page_id);


--
-- Name: idx_password_reset_tokens_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_password_reset_tokens_expires_at ON public.password_reset_tokens USING btree (expires_at) WHERE (used_at IS NULL);


--
-- Name: idx_password_reset_tokens_token_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_password_reset_tokens_token_hash ON public.password_reset_tokens USING btree (token_hash) WHERE (used_at IS NULL);


--
-- Name: idx_password_reset_tokens_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_password_reset_tokens_user_id ON public.password_reset_tokens USING btree (user_id) WHERE (used_at IS NULL);


--
-- Name: idx_profiles_agency_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_agency_id ON public.profiles USING btree (agency_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_profiles_employee_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_employee_code ON public.profiles USING btree (employee_code) WHERE ((employee_code IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_profiles_full_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_full_name ON public.profiles USING btree (full_name) WHERE (deleted_at IS NULL);


--
-- Name: idx_profiles_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_is_active ON public.profiles USING btree (is_active) WHERE (deleted_at IS NULL);


--
-- Name: idx_profiles_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_profiles_user_id ON public.profiles USING btree (user_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_system_alert_rules_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_alert_rules_enabled ON public.system_alert_rules USING btree (is_enabled);


--
-- Name: idx_system_alert_rules_metric; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_alert_rules_metric ON public.system_alert_rules USING btree (metric_name) WHERE (is_enabled = true);


--
-- Name: idx_system_alerts_alert_rule_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_alerts_alert_rule_id ON public.system_alerts USING btree (alert_rule_id);


--
-- Name: idx_system_alerts_severity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_alerts_severity ON public.system_alerts USING btree (severity);


--
-- Name: idx_system_alerts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_alerts_status ON public.system_alerts USING btree (status);


--
-- Name: idx_system_alerts_triggered_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_alerts_triggered_at ON public.system_alerts USING btree (triggered_at);


--
-- Name: idx_system_health_metrics_db_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_health_metrics_db_status ON public.system_health_metrics USING btree (db_status);


--
-- Name: idx_system_health_metrics_overall_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_health_metrics_overall_status ON public.system_health_metrics USING btree (overall_status);


--
-- Name: idx_system_health_metrics_redis_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_health_metrics_redis_status ON public.system_health_metrics USING btree (redis_status);


--
-- Name: idx_system_health_metrics_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_health_metrics_timestamp ON public.system_health_metrics USING btree ("timestamp");


--
-- Name: idx_system_incidents_assigned_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_incidents_assigned_to ON public.system_incidents USING btree (assigned_to);


--
-- Name: idx_system_incidents_severity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_incidents_severity ON public.system_incidents USING btree (severity);


--
-- Name: idx_system_incidents_started_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_incidents_started_at ON public.system_incidents USING btree (started_at);


--
-- Name: idx_system_incidents_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_incidents_status ON public.system_incidents USING btree (status);


--
-- Name: idx_system_settings_singleton; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_system_settings_singleton ON public.system_settings USING btree ((1));


--
-- Name: idx_system_sla_metrics_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_sla_metrics_date ON public.system_sla_metrics USING btree (metric_date);


--
-- Name: idx_system_sla_metrics_service; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_sla_metrics_service ON public.system_sla_metrics USING btree (service_name);


--
-- Name: idx_tickets_agency_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_agency_id ON public.tickets USING btree (agency_id);


--
-- Name: idx_tickets_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_created_at ON public.tickets USING btree (created_at);


--
-- Name: idx_tickets_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_priority ON public.tickets USING btree (priority);


--
-- Name: idx_tickets_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_status ON public.tickets USING btree (status);


--
-- Name: idx_tickets_ticket_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_ticket_number ON public.tickets USING btree (ticket_number);


--
-- Name: idx_tickets_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_user_id ON public.tickets USING btree (user_id);


--
-- Name: idx_user_roles_active_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_user_roles_active_unique ON public.user_roles USING btree (user_id, role, agency_id) WHERE ((is_active = true) AND (revoked_at IS NULL));


--
-- Name: idx_user_roles_agency_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_agency_id ON public.user_roles USING btree (agency_id) WHERE (agency_id IS NOT NULL);


--
-- Name: idx_user_roles_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_is_active ON public.user_roles USING btree (is_active);


--
-- Name: idx_user_roles_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_role ON public.user_roles USING btree (role);


--
-- Name: idx_user_roles_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_user_id ON public.user_roles USING btree (user_id);


--
-- Name: idx_user_roles_valid_until; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_valid_until ON public.user_roles USING btree (valid_until) WHERE (valid_until IS NOT NULL);


--
-- Name: idx_user_sessions_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_expires_at ON public.user_sessions USING btree (expires_at) WHERE (is_active = true);


--
-- Name: idx_user_sessions_token_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_user_sessions_token_hash ON public.user_sessions USING btree (token_hash) WHERE ((is_active = true) AND (revoked_at IS NULL));


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id) WHERE (is_active = true);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_email_confirmed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email_confirmed ON public.users USING btree (email_confirmed) WHERE (deleted_at IS NULL);


--
-- Name: idx_users_email_normalized; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_email_normalized ON public.users USING btree (email_normalized) WHERE (deleted_at IS NULL);


--
-- Name: idx_users_locked_until; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_locked_until ON public.users USING btree (locked_until) WHERE (locked_until IS NOT NULL);


--
-- Name: idx_users_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_phone ON public.users USING btree (phone) WHERE ((phone IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_status ON public.users USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: unique_agency_page; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_agency_page ON public.agency_page_assignments USING btree (agency_id, page_id);


--
-- Name: unique_page_tier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_page_tier ON public.page_pricing_tiers USING btree (page_id, tier_name, billing_cycle);


--
-- Name: unique_page_usage_daily; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_page_usage_daily ON public.page_usage_analytics USING btree (agency_id, page_id, date, user_id);


--
-- Name: unique_sla_metric_per_service_day; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_sla_metric_per_service_day ON public.system_sla_metrics USING btree (metric_date, service_name);


--
-- Name: agencies agencies_owner_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agencies
    ADD CONSTRAINT agencies_owner_user_id_users_id_fk FOREIGN KEY (owner_user_id) REFERENCES public.users(id);


--
-- Name: agency_page_assignments agency_page_assignments_agency_id_agencies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_assignments
    ADD CONSTRAINT agency_page_assignments_agency_id_agencies_id_fk FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE CASCADE;


--
-- Name: agency_page_assignments agency_page_assignments_assigned_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_assignments
    ADD CONSTRAINT agency_page_assignments_assigned_by_users_id_fk FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: agency_page_assignments agency_page_assignments_page_id_page_catalog_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_assignments
    ADD CONSTRAINT agency_page_assignments_page_id_page_catalog_id_fk FOREIGN KEY (page_id) REFERENCES public.page_catalog(id) ON DELETE CASCADE;


--
-- Name: agency_page_assignments agency_page_assignments_suspended_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_assignments
    ADD CONSTRAINT agency_page_assignments_suspended_by_users_id_fk FOREIGN KEY (suspended_by) REFERENCES public.users(id);


--
-- Name: agency_page_requests agency_page_requests_agency_id_agencies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_requests
    ADD CONSTRAINT agency_page_requests_agency_id_agencies_id_fk FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE CASCADE;


--
-- Name: agency_page_requests agency_page_requests_page_id_page_catalog_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_requests
    ADD CONSTRAINT agency_page_requests_page_id_page_catalog_id_fk FOREIGN KEY (page_id) REFERENCES public.page_catalog(id) ON DELETE CASCADE;


--
-- Name: agency_page_requests agency_page_requests_requested_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_requests
    ADD CONSTRAINT agency_page_requests_requested_by_users_id_fk FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: agency_page_requests agency_page_requests_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_page_requests
    ADD CONSTRAINT agency_page_requests_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: agency_provisioning_jobs agency_provisioning_jobs_agency_id_agencies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_provisioning_jobs
    ADD CONSTRAINT agency_provisioning_jobs_agency_id_agencies_id_fk FOREIGN KEY (agency_id) REFERENCES public.agencies(id);


--
-- Name: agency_provisioning_jobs agency_provisioning_jobs_cancelled_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_provisioning_jobs
    ADD CONSTRAINT agency_provisioning_jobs_cancelled_by_users_id_fk FOREIGN KEY (cancelled_by) REFERENCES public.users(id);


--
-- Name: agency_provisioning_jobs agency_provisioning_jobs_requested_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_provisioning_jobs
    ADD CONSTRAINT agency_provisioning_jobs_requested_by_users_id_fk FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: agency_provisioning_logs agency_provisioning_logs_job_id_agency_provisioning_jobs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agency_provisioning_logs
    ADD CONSTRAINT agency_provisioning_logs_job_id_agency_provisioning_jobs_id_fk FOREIGN KEY (job_id) REFERENCES public.agency_provisioning_jobs(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_agency_id_agencies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_agency_id_agencies_id_fk FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_session_id_user_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_session_id_user_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.user_sessions(id);


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: email_verification_tokens email_verification_tokens_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_agency_id_agencies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_agency_id_agencies_id_fk FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: page_catalog page_catalog_parent_page_id_page_catalog_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_catalog
    ADD CONSTRAINT page_catalog_parent_page_id_page_catalog_id_fk FOREIGN KEY (parent_page_id) REFERENCES public.page_catalog(id) ON DELETE SET NULL;


--
-- Name: page_catalog page_catalog_replacement_page_id_page_catalog_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_catalog
    ADD CONSTRAINT page_catalog_replacement_page_id_page_catalog_id_fk FOREIGN KEY (replacement_page_id) REFERENCES public.page_catalog(id);


--
-- Name: page_pricing_tiers page_pricing_tiers_page_id_page_catalog_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_pricing_tiers
    ADD CONSTRAINT page_pricing_tiers_page_id_page_catalog_id_fk FOREIGN KEY (page_id) REFERENCES public.page_catalog(id) ON DELETE CASCADE;


--
-- Name: page_recommendation_rules page_recommendation_rules_page_id_page_catalog_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_recommendation_rules
    ADD CONSTRAINT page_recommendation_rules_page_id_page_catalog_id_fk FOREIGN KEY (page_id) REFERENCES public.page_catalog(id) ON DELETE CASCADE;


--
-- Name: page_usage_analytics page_usage_analytics_agency_id_agencies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_usage_analytics
    ADD CONSTRAINT page_usage_analytics_agency_id_agencies_id_fk FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE CASCADE;


--
-- Name: page_usage_analytics page_usage_analytics_page_id_page_catalog_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_usage_analytics
    ADD CONSTRAINT page_usage_analytics_page_id_page_catalog_id_fk FOREIGN KEY (page_id) REFERENCES public.page_catalog(id) ON DELETE CASCADE;


--
-- Name: page_usage_analytics page_usage_analytics_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.page_usage_analytics
    ADD CONSTRAINT page_usage_analytics_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_agency_id_agencies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_agency_id_agencies_id_fk FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: system_alerts system_alerts_acknowledged_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_acknowledged_by_users_id_fk FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: system_alerts system_alerts_alert_rule_id_system_alert_rules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_alert_rule_id_system_alert_rules_id_fk FOREIGN KEY (alert_rule_id) REFERENCES public.system_alert_rules(id) ON DELETE SET NULL;


--
-- Name: system_alerts system_alerts_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: system_incidents system_incidents_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_incidents
    ADD CONSTRAINT system_incidents_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: system_incidents system_incidents_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_incidents
    ADD CONSTRAINT system_incidents_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tickets tickets_agency_id_agencies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_agency_id_agencies_id_fk FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: tickets tickets_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_roles user_roles_agency_id_agencies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_agency_id_agencies_id_fk FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_assigned_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_users_id_fk FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_revoked_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_revoked_by_users_id_fk FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict erNzoVyUqWtYM7Yb8wpVOfUsauAd1iaknCei9BRnyVtZ6F9d1fnjjiwTZVeXHC2

